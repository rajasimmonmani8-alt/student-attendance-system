CREATE DATABASE IF NOT EXISTS student_attendance_system
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE student_attendance_system;

CREATE TABLE IF NOT EXISTS settings (
    setting_key VARCHAR(100) NOT NULL PRIMARY KEY,
    setting_value LONGTEXT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS students (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    student_code VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(150) NOT NULL,
    class_name VARCHAR(100) DEFAULT '',
    roll_number VARCHAR(50) DEFAULT '',
    email VARCHAR(150) DEFAULT '',
    phone VARCHAR(50) DEFAULT '',
    parent_contact VARCHAR(150) DEFAULT '',
    status VARCHAR(30) NOT NULL DEFAULT 'Active',
    face_descriptor LONGTEXT NULL,
    face_image_path VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS attendance_logs (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    attendance_code VARCHAR(50) NOT NULL UNIQUE,
    student_id INT NULL,
    student_code VARCHAR(50) DEFAULT NULL,
    student_name VARCHAR(150) NOT NULL,
    attendance_status VARCHAR(30) NOT NULL DEFAULT 'Present',
    match_confidence DECIMAL(6,4) DEFAULT NULL,
    recognition_source VARCHAR(80) NOT NULL DEFAULT 'dashboard',
    device_id VARCHAR(80) NOT NULL DEFAULT 'DASHBOARD-CAM-001',
    attendance_date DATE NOT NULL,
    attendance_time DATETIME NOT NULL,
    snapshot_path VARCHAR(255) DEFAULT NULL,
    notes TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_attendance_student
        FOREIGN KEY (student_id) REFERENCES students (id)
        ON DELETE SET NULL
);

CREATE INDEX idx_attendance_date_status ON attendance_logs (attendance_date, attendance_status);
CREATE INDEX idx_attendance_student_date ON attendance_logs (student_id, attendance_date);

CREATE TABLE IF NOT EXISTS alerts (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    alert_code VARCHAR(50) NOT NULL UNIQUE,
    attendance_log_id INT NULL,
    student_id INT NULL,
    student_label VARCHAR(150) NOT NULL,
    reason VARCHAR(255) NOT NULL,
    image_path VARCHAR(255) DEFAULT NULL,
    device_id VARCHAR(80) NOT NULL DEFAULT 'DASHBOARD-CAM-001',
    telegram_sent TINYINT(1) NOT NULL DEFAULT 0,
    resolved TINYINT(1) NOT NULL DEFAULT 0,
    resolution_notes TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME DEFAULT NULL,
    CONSTRAINT fk_alert_attendance
        FOREIGN KEY (attendance_log_id) REFERENCES attendance_logs (id)
        ON DELETE SET NULL,
    CONSTRAINT fk_alert_student
        FOREIGN KEY (student_id) REFERENCES students (id)
        ON DELETE SET NULL
);

CREATE INDEX idx_alert_created ON alerts (created_at, resolved);

INSERT INTO settings (setting_key, setting_value) VALUES
    ('institution_name', 'Student Attendance System'),
    ('device_id', 'DASHBOARD-CAM-001'),
    ('recognition_threshold', '0.48'),
    ('unknown_alert_cooldown_seconds', '30'),
    ('face_model_url', 'https://justadudewhohacks.github.io/face-api.js/models'),
    ('server_recognition_model', 'gpt-4.1-mini'),
    ('server_recognition_max_candidates', '8'),
    ('esp32_api_token', ''),
    ('notify_telegram', '1'),
    ('notify_alerts', '1'),
    ('daily_report_enabled', '0'),
    ('telegram_bot_token', ''),
    ('telegram_chat_id', '')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);
