const CONFIG = {
    API_BASE: 'api',
    REFRESH_INTERVAL: 30000,
    RECOGNITION_SCAN_INTERVAL: 3000,
    RECOGNITION_COOLDOWN_MS: 45000,
    CHART_COLORS: {
        primary: '#4285f4',
        success: '#34a853',
        warning: '#fbbc04',
        danger: '#ea4335',
        secondary: '#5f6368'
    }
};

const DEFAULT_SETTINGS = {
    institution_name: 'Student Attendance System',
    device_id: 'DASHBOARD-CAM-001',
    wifi_ssid: '',
    wifi_password: '',
    telegram_bot_token: '',
    telegram_chat_id: '',
    ai_api_key: '',
    recognition_threshold: '0.48',
    unknown_alert_cooldown_seconds: '30',
    face_model_url: 'https://justadudewhohacks.github.io/face-api.js/models',
    server_recognition_model: 'gpt-4.1-mini',
    server_recognition_max_candidates: '8',
    esp32_api_token: '',
    notify_telegram: '1',
    notify_alerts: '1',
    daily_report_enabled: '0'
};

const state = {
    currentPage: 'dashboard',
    charts: {
        attendance: null,
        peakHours: null,
        distribution: null,
        hourly: null,
        weekly: null,
        weeklyDistribution: null,
        monthly: null
    },
    dashboardChartRange: 'week',
    dashboardChartData: {
        week: { labels: [], present: [], absent: [] },
        month: { labels: [], present: [], absent: [] },
        year: { labels: [], present: [], absent: [] }
    },
    dashboardStats: null,
    settings: { ...DEFAULT_SETTINGS },
    students: [],
    alerts: [],
    autoRefreshTimer: null,
    recognition: {
        modelsLoaded: false,
        matcher: null,
        stream: null,
        isRunning: false,
        isBusy: false,
        intervalId: null,
        lastRecognizedAt: {},
        lastUnknownAt: 0
    }
};

document.addEventListener('DOMContentLoaded', () => {
    initializeApp().catch((error) => {
        console.error(error);
        showToast(error.message || 'Unable to start dashboard.', 'error');
    });
});

async function initializeApp() {
    setCurrentDate();
    populateYearOptions();
    initNavigation();
    initEventListeners();
    initCharts();
    await loadSettings();
    await loadStudents();
    await loadDashboardData();
    updateRecognitionSummary();
    startAutoRefresh();
}

function initNavigation() {
    document.querySelectorAll('.nav-item').forEach((item) => {
        item.addEventListener('click', () => navigateTo(item.dataset.page));
    });
}

function initEventListeners() {
    document.getElementById('menuToggle')?.addEventListener('click', () => {
        document.querySelector('.sidebar')?.classList.toggle('active');
    });
    document.getElementById('notificationBtn')?.addEventListener('click', () => navigateTo('alerts'));
    document.getElementById('refreshBtn')?.addEventListener('click', async () => {
        await loadPageData(state.currentPage, true);
        showToast('Data refreshed successfully.');
    });
    document.querySelectorAll('.btn-chart').forEach((button) => {
        button.addEventListener('click', () => {
            document.querySelectorAll('.btn-chart').forEach((item) => item.classList.remove('active'));
            button.classList.add('active');
            state.dashboardChartRange = button.dataset.range || 'week';
            updateAttendanceChart();
        });
    });
    document.getElementById('dailyDate')?.addEventListener('change', () => loadDailyReport().catch(handleUiError));
    document.getElementById('weekStart')?.addEventListener('change', () => loadWeeklyReport().catch(handleUiError));
    document.getElementById('weekEnd')?.addEventListener('change', () => loadWeeklyReport().catch(handleUiError));
    document.getElementById('monthSelect')?.addEventListener('change', () => loadMonthlyReport().catch(handleUiError));
    document.getElementById('yearSelect')?.addEventListener('change', () => loadMonthlyReport().catch(handleUiError));
    document.getElementById('alertFilter')?.addEventListener('change', () => loadAlerts().catch(handleUiError));
    document.getElementById('alertDateFilter')?.addEventListener('change', () => loadAlerts().catch(handleUiError));
    document.getElementById('studentSearch')?.addEventListener('input', debounce(applyStudentFilters, 200));
    document.getElementById('classFilter')?.addEventListener('change', applyStudentFilters);
    document.getElementById('searchInput')?.addEventListener('input', debounce(applyStudentFilters, 200));
    document.getElementById('threshold')?.addEventListener('input', updateThresholdDisplay);
    document.getElementById('studentFaceImage')?.addEventListener('change', handleStudentFaceSelection);
    document.getElementById('startRecognitionBtn')?.addEventListener('click', () => startRecognition().catch(handleUiError));
    document.getElementById('stopRecognitionBtn')?.addEventListener('click', stopRecognition);
    document.getElementById('scanRecognitionBtn')?.addEventListener('click', () => scanRecognitionFrame().catch(handleUiError));
    document.querySelectorAll('.modal').forEach((modal) => {
        modal.addEventListener('click', (event) => {
            if (event.target === modal) {
                closeModal(modal.id);
            }
        });
    });
}

async function apiRequest(endpoint, options = {}) {
    const requestOptions = {
        method: options.method || 'GET',
        headers: {
            'Content-Type': 'application/json',
            ...(options.headers || {})
        }
    };

    if (options.body !== undefined) {
        requestOptions.body = JSON.stringify(options.body);
    }

    const response = await fetch(`${CONFIG.API_BASE}/${endpoint}`, requestOptions);
    const payload = await response.json().catch(() => {
        throw new Error('The server returned an invalid response.');
    });

    if (!response.ok || payload.success === false) {
        const message = payload.details
            ? `${payload.message || 'Request failed.'} ${payload.details}`.trim()
            : (payload.message || 'Request failed.');
        throw new Error(message);
    }

    return payload;
}

function initCharts() {
    if (typeof Chart === 'undefined') {
        return;
    }

    state.charts.attendance = new Chart(document.getElementById('attendanceChart'), {
        type: 'bar',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'Present',
                    data: [],
                    backgroundColor: CONFIG.CHART_COLORS.success,
                    borderRadius: 4
                },
                {
                    label: 'Absent',
                    data: [],
                    backgroundColor: CONFIG.CHART_COLORS.danger,
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'top' } },
            scales: {
                y: { beginAtZero: true, grid: { color: '#f0f0f0' } },
                x: { grid: { display: false } }
            }
        }
    });

    state.charts.peakHours = new Chart(document.getElementById('peakHoursChart'), {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Check-ins',
                data: [],
                borderColor: CONFIG.CHART_COLORS.primary,
                backgroundColor: 'rgba(66, 133, 244, 0.1)',
                fill: true,
                tension: 0.35
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true } }
        }
    });

    state.charts.distribution = new Chart(document.getElementById('distributionChart'), {
        type: 'doughnut',
        data: {
            labels: ['Present', 'Absent', 'Alerts'],
            datasets: [{
                data: [0, 0, 0],
                backgroundColor: [
                    CONFIG.CHART_COLORS.success,
                    CONFIG.CHART_COLORS.danger,
                    CONFIG.CHART_COLORS.warning
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom' } }
        }
    });
}

async function loadSettings() {
    const response = await apiRequest('settings.php');
    state.settings = { ...DEFAULT_SETTINGS, ...(response.settings || {}) };
    applySettingsToForm();
    updateThresholdDisplay();
}

function applySettingsToForm() {
    document.getElementById('institutionName').value = state.settings.institution_name || '';
    document.getElementById('dashboardDevice').value = state.settings.device_id || '';
    document.getElementById('wifiSSID').value = state.settings.wifi_ssid || '';
    document.getElementById('wifiPassword').value = state.settings.wifi_password || '';
    document.getElementById('telegramToken').value = state.settings.telegram_bot_token || '';
    document.getElementById('chatID').value = state.settings.telegram_chat_id || '';
    document.getElementById('aiAPIKey').value = state.settings.ai_api_key || '';
    document.getElementById('faceModelUrl').value = state.settings.face_model_url || DEFAULT_SETTINGS.face_model_url;
    document.getElementById('unknownAlertCooldown').value = state.settings.unknown_alert_cooldown_seconds || '30';
    document.getElementById('serverRecognitionModel').value = state.settings.server_recognition_model || DEFAULT_SETTINGS.server_recognition_model;
    document.getElementById('serverRecognitionMaxCandidates').value = state.settings.server_recognition_max_candidates || DEFAULT_SETTINGS.server_recognition_max_candidates;
    document.getElementById('esp32ApiToken').value = state.settings.esp32_api_token || '';
    document.getElementById('notifyTelegram').checked = String(state.settings.notify_telegram) !== '0';
    document.getElementById('notifyAlerts').checked = String(state.settings.notify_alerts) !== '0';
    document.getElementById('dailyReport').checked = String(state.settings.daily_report_enabled) === '1';

    const threshold = Math.round(parseFloat(state.settings.recognition_threshold || '0.48') * 100);
    document.getElementById('threshold').value = Number.isFinite(threshold) ? threshold : 48;
}

function updateThresholdDisplay() {
    const sliderValue = Number(document.getElementById('threshold')?.value || 48);
    const decimalThreshold = (sliderValue / 100).toFixed(2);
    document.getElementById('thresholdValue').textContent = decimalThreshold;
    document.getElementById('recognitionThresholdDisplay').textContent = decimalThreshold;
}

async function loadDashboardData() {
    const response = await apiRequest('dashboard.php');
    state.dashboardStats = response.stats;
    state.dashboardChartData = response.charts.attendance;

    setText('todayPresent', response.stats.todayPresent);
    setText('todayAbsent', response.stats.todayAbsent);
    setText('attendanceRate', response.stats.attendanceRate);
    setText('todayAlerts', response.stats.todayAlerts);
    setText('alertBadge', response.stats.todayAlerts);
    setText('notificationCount', response.stats.todayAlerts);

    updateAttendanceChart();
    updatePeakHoursChart(response.charts.peakHours);
    updateDistributionChart(response.charts.distribution);
    updateRecentActivity(response.recentActivity || []);
    updateRecentAlerts(response.recentAlerts || []);
    updateUnwantedImages(response.unwantedImages || []);
    updateRecognitionSummary();
}

function updateAttendanceChart() {
    const chart = state.charts.attendance;
    if (!chart) {
        return;
    }

    const rangeData = state.dashboardChartData[state.dashboardChartRange] || state.dashboardChartData.week;
    chart.data.labels = rangeData.labels || [];
    chart.data.datasets[0].data = rangeData.present || [];
    chart.data.datasets[1].data = rangeData.absent || [];
    chart.update();
}

function updatePeakHoursChart(data) {
    const chart = state.charts.peakHours;
    if (!chart) {
        return;
    }

    chart.data.labels = data.labels || [];
    chart.data.datasets[0].data = data.data || [];
    chart.update();
}

function updateDistributionChart(data) {
    const chart = state.charts.distribution;
    if (!chart) {
        return;
    }

    chart.data.labels = data.labels || [];
    chart.data.datasets[0].data = data.data || [];
    chart.update();
}

function updateRecentActivity(activities) {
    const container = document.getElementById('recentActivity');
    container.innerHTML = activities.length
        ? ''
        : '<div class="activity-item"><div class="activity-details"><h4>No attendance activity yet</h4><p>Recognized students will appear here.</p></div></div>';

    activities.forEach((activity) => {
        const item = document.createElement('div');
        item.className = 'activity-item';
        item.innerHTML = `
            <div class="activity-icon ${activity.action}">
                <i class="fas fa-${activity.action === 'present' ? 'check' : 'exclamation'}"></i>
            </div>
            <div class="activity-details">
                <h4>${escapeHtml(activity.name)}</h4>
                <p>${activity.action === 'present' ? 'Attendance recorded' : 'Alert generated'} - ID: ${escapeHtml(activity.studentId)}</p>
            </div>
            <span class="activity-time">${formatShortTimestamp(activity.time)}</span>
        `;
        container.appendChild(item);
    });
}

function updateRecentAlerts(alerts) {
    const container = document.getElementById('recentAlerts');
    container.innerHTML = alerts.length
        ? ''
        : '<div class="alert-item"><div class="alert-details"><h4>No alerts today</h4><p>Unknown-person alerts will appear here.</p></div></div>';

    alerts.forEach((alert) => {
        const item = document.createElement('div');
        item.className = 'alert-item';
        item.innerHTML = `
            <div class="alert-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="alert-details">
                <h4>${escapeHtml(alert.reason)}</h4>
                <p>${escapeHtml(alert.id)} - ${alert.resolved ? 'Resolved' : 'Pending'}</p>
            </div>
            <span class="alert-time">${formatShortTimestamp(alert.time)}</span>
        `;
        container.appendChild(item);
    });
}

function updateUnwantedImages(images) {
    const container = document.getElementById('unwantedImages');
    const countBadge = document.getElementById('unwantedCount');
    container.innerHTML = '';
    countBadge.textContent = `${images.length} flagged`;

    if (!images.length) {
        container.innerHTML = '<div class="image-card"><div class="overlay"><h4>No flagged images</h4><p>Unknown-person snapshots will appear here.</p></div></div>';
        return;
    }

    images.forEach((image) => {
        const card = document.createElement('div');
        card.className = 'image-card';
        card.innerHTML = `
            <img src="${image.url}" alt="Flagged image">
            <span class="flag"><i class="fas fa-flag"></i> Alert</span>
            <div class="overlay">
                <h4>${escapeHtml(image.reason)}</h4>
                <p>${formatShortTimestamp(image.time)}</p>
            </div>
        `;
        card.addEventListener('click', () => showImageModal(image));
        container.appendChild(card);
    });
}

async function loadDailyReport() {
    const date = document.getElementById('dailyDate').value || new Date().toISOString().split('T')[0];
    const response = await apiRequest(`attendance.php?report=daily&date=${encodeURIComponent(date)}`);
    const report = response.report;

    setText('dailyPresent', report.present);
    setText('dailyAbsent', report.absent);
    setText('dailyRate', report.rate);
    setText('dailyPeak', report.peakHour);

    if (!state.charts.hourly) {
        state.charts.hourly = new Chart(document.getElementById('hourlyChart'), {
            type: 'bar',
            data: {
                labels: report.hourlyLabels,
                datasets: [{
                    label: 'Attendance',
                    data: report.hourlyData,
                    backgroundColor: CONFIG.CHART_COLORS.primary,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    } else {
        state.charts.hourly.data.labels = report.hourlyLabels;
        state.charts.hourly.data.datasets[0].data = report.hourlyData;
        state.charts.hourly.update();
    }

    const tbody = document.getElementById('dailyTableBody');
    tbody.innerHTML = report.tableData.length
        ? ''
        : '<tr><td colspan="6">No attendance records found for this date.</td></tr>';

    report.tableData.forEach((row) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${escapeHtml(row.id)}</td>
            <td>${formatTimeOnly(row.time)}</td>
            <td>${escapeHtml(row.studentId)}</td>
            <td>${escapeHtml(row.name)}</td>
            <td><span class="status-badge ${row.status.toLowerCase()}">${escapeHtml(row.status)}</span></td>
            <td>${escapeHtml(row.device)}</td>
        `;
        tbody.appendChild(tr);
    });
}

async function loadWeeklyReport() {
    const startDate = document.getElementById('weekStart').value;
    const endDate = document.getElementById('weekEnd').value;
    const response = await apiRequest(
        `attendance.php?report=weekly&startDate=${encodeURIComponent(startDate)}&endDate=${encodeURIComponent(endDate)}`
    );
    const report = response.report;

    setText('weeklyPresent', report.present);
    setText('weeklyAbsent', report.absent);
    setText('weeklyRate', report.rate);
    setText('weeklyActiveDay', report.activeDay);

    if (!state.charts.weekly) {
        state.charts.weekly = new Chart(document.getElementById('weeklyChart'), {
            type: 'line',
            data: {
                labels: report.labels,
                datasets: [{
                    label: 'Attendance',
                    data: report.weeklyData,
                    borderColor: CONFIG.CHART_COLORS.primary,
                    backgroundColor: 'rgba(66, 133, 244, 0.1)',
                    fill: true,
                    tension: 0.35
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    } else {
        state.charts.weekly.data.labels = report.labels;
        state.charts.weekly.data.datasets[0].data = report.weeklyData;
        state.charts.weekly.update();
    }

    if (!state.charts.weeklyDistribution) {
        state.charts.weeklyDistribution = new Chart(document.getElementById('weeklyDistributionChart'), {
            type: 'pie',
            data: {
                labels: report.distributionLabels,
                datasets: [{
                    data: report.distributionData,
                    backgroundColor: ['#4285f4', '#34a853', '#fbbc04', '#ea4335', '#5f6368', '#7c3aed', '#0f766e']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    } else {
        state.charts.weeklyDistribution.data.labels = report.distributionLabels;
        state.charts.weeklyDistribution.data.datasets[0].data = report.distributionData;
        state.charts.weeklyDistribution.update();
    }
}

async function loadMonthlyReport() {
    const month = document.getElementById('monthSelect').value;
    const year = document.getElementById('yearSelect').value;
    const response = await apiRequest(
        `attendance.php?report=monthly&month=${encodeURIComponent(month)}&year=${encodeURIComponent(year)}`
    );
    const report = response.report;

    setText('monthlyPresent', report.present);
    setText('monthlyAbsent', report.absent);
    setText('monthlyRate', report.rate);
    setText('monthlyBestDay', report.bestDay);
    setText('monthlyWorstDay', report.worstDay);

    if (!state.charts.monthly) {
        state.charts.monthly = new Chart(document.getElementById('monthlyChart'), {
            type: 'bar',
            data: {
                labels: report.labels,
                datasets: [{
                    label: 'Daily Attendance',
                    data: report.dailyData,
                    backgroundColor: CONFIG.CHART_COLORS.primary,
                    borderRadius: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } }
            }
        });
    } else {
        state.charts.monthly.data.labels = report.labels;
        state.charts.monthly.data.datasets[0].data = report.dailyData;
        state.charts.monthly.update();
    }
}

async function loadAlerts() {
    const filter = document.getElementById('alertFilter').value;
    const dateFilter = document.getElementById('alertDateFilter').value;
    const query = `alerts.php?filter=${encodeURIComponent(filter)}&date=${encodeURIComponent(dateFilter)}`;
    const response = await apiRequest(query);
    state.alerts = response.alerts || [];
    updateAlertsUI();
}

function updateAlertsUI() {
    const container = document.getElementById('alertsGrid');
    container.innerHTML = state.alerts.length
        ? ''
        : '<div class="alert-card"><div class="alert-card-content"><p>No alerts found.</p></div></div>';

    state.alerts.forEach((alert) => {
        const card = document.createElement('div');
        card.className = 'alert-card';
        card.innerHTML = `
            <img src="${alert.image || 'https://via.placeholder.com/400x300?text=No+Image'}" alt="Alert snapshot" class="alert-card-image">
            <div class="alert-card-content">
                <div class="alert-card-header">
                    <h4>${escapeHtml(alert.alertCode)}</h4>
                    <span class="alert-status ${alert.resolved ? 'resolved' : 'unresolved'}">
                        ${alert.resolved ? 'Resolved' : 'Unresolved'}
                    </span>
                </div>
                <div class="alert-card-body">
                    <p><strong>Reason:</strong> ${escapeHtml(alert.reason)}</p>
                    <p><strong>Student:</strong> ${escapeHtml(alert.studentId)}</p>
                    <p><strong>Device:</strong> ${escapeHtml(alert.device)}</p>
                </div>
                <div class="alert-card-footer">
                    <span class="alert-card-time">${formatShortTimestamp(alert.time)}</span>
                    <button class="btn-secondary">View Details</button>
                </div>
            </div>
        `;
        card.addEventListener('click', () => showAlertDialogById(alert.id));
        card.querySelector('button').addEventListener('click', (event) => {
            event.stopPropagation();
            showAlertDialogById(alert.id);
        });
        container.appendChild(card);
    });
}

function showAlertDialogById(alertId) {
    const alert = state.alerts.find((item) => Number(item.id) === Number(alertId));
    if (!alert) {
        return;
    }

    document.getElementById('alertModalImage').src = alert.image || 'https://via.placeholder.com/400x300?text=No+Image';
    document.getElementById('alertModalId').textContent = alert.alertCode;
    document.getElementById('alertModalTime').textContent = formatFullTimestamp(alert.time);
    document.getElementById('alertModalStudent').textContent = alert.studentId;
    document.getElementById('alertModalReason').textContent = alert.reason;
    document.getElementById('alertModalDevice').textContent = alert.device;
    document.getElementById('resolutionNotes').value = alert.resolutionNotes || '';
    document.getElementById('resolutionNotes').dataset.alertId = String(alert.id);
    openModal('alertModal');
}

async function resolveAlert() {
    try {
        const alertId = Number(document.getElementById('resolutionNotes').dataset.alertId || 0);
        const resolutionNotes = document.getElementById('resolutionNotes').value;
        if (!alertId) {
            return;
        }

        await apiRequest('alerts.php', {
            method: 'POST',
            body: {
                action: 'resolve',
                id: alertId,
                resolutionNotes
            }
        });

        closeModal('alertModal');
        await loadAlerts();
        await loadDashboardData();
        showToast('Alert resolved successfully.');
    } catch (error) {
        handleUiError(error);
    }
}

async function clearAllAlerts() {
    try {
        if (!window.confirm('Are you sure you want to clear all alerts?')) {
            return;
        }

        await apiRequest('alerts.php', {
            method: 'POST',
            body: { action: 'clear_all' }
        });

        await loadAlerts();
        await loadDashboardData();
        showToast('All alerts cleared.');
    } catch (error) {
        handleUiError(error);
    }
}

async function loadStudents() {
    const response = await apiRequest('students.php');
    state.students = response.students || [];
    applyStudentFilters();
    rebuildFaceMatcher();
}

function applyStudentFilters() {
    const textFilter = (document.getElementById('studentSearch').value || document.getElementById('searchInput').value || '')
        .trim()
        .toLowerCase();
    const classFilter = (document.getElementById('classFilter').value || '').trim().toLowerCase();

    const filteredStudents = state.students.filter((student) => {
        const matchesText = !textFilter
            || student.studentCode.toLowerCase().includes(textFilter)
            || student.fullName.toLowerCase().includes(textFilter)
            || (student.className || '').toLowerCase().includes(textFilter);
        const matchesClass = !classFilter || (student.className || '').toLowerCase() === classFilter;
        return matchesText && matchesClass;
    });

    updateStudentsUI(filteredStudents);
}

function updateStudentsUI(students) {
    const tbody = document.getElementById('studentsTableBody');
    tbody.innerHTML = students.length
        ? ''
        : '<tr><td colspan="9">No students available. Add a student with a face photo to start automatic attendance.</td></tr>';

    students.forEach((student) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${escapeHtml(student.studentCode)}</td>
            <td>${escapeHtml(student.fullName)}</td>
            <td>${escapeHtml(student.className || '-')}</td>
            <td>${escapeHtml(student.rollNumber || '-')}</td>
            <td><span class="status-badge ${student.status.toLowerCase()}">${escapeHtml(student.status)}</span></td>
            <td>
                <span class="face-status ${student.faceEnrolled ? 'enrolled' : 'pending'}">
                    <i class="fas fa-${student.faceEnrolled ? 'check-circle' : 'clock'}"></i>
                    ${student.faceEnrolled ? 'Enrolled' : 'Not Ready'}
                </span>
            </td>
            <td>${student.checkins}</td>
            <td>${student.lastSeenAt ? formatShortTimestamp(student.lastSeenAt) : '-'}</td>
            <td>
                <div class="action-btns">
                    <button class="action-btn edit" onclick="editStudent(${student.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete" onclick="deleteStudent(${student.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function showAddStudentModal() {
    document.getElementById('studentModalTitle').textContent = 'Add Student';
    document.getElementById('studentForm').reset();
    document.getElementById('studentRecordId').value = '';
    document.getElementById('studentId').value = `STU${Date.now().toString().slice(-6)}`;
    document.getElementById('studentStatus').value = 'Active';
    document.getElementById('existingFaceDescriptor').value = '';
    document.getElementById('existingFaceImageUrl').value = '';
    document.getElementById('studentFaceImage').value = '';
    setStudentFacePreview('');
    openModal('studentModal');
}

function editStudent(studentId) {
    const student = state.students.find((item) => Number(item.id) === Number(studentId));
    if (!student) {
        return;
    }

    document.getElementById('studentModalTitle').textContent = 'Edit Student';
    document.getElementById('studentRecordId').value = student.id;
    document.getElementById('studentId').value = student.studentCode;
    document.getElementById('studentName').value = student.fullName;
    document.getElementById('studentClass').value = student.className || 'Class A';
    document.getElementById('rollNumber').value = student.rollNumber || '';
    document.getElementById('studentEmail').value = student.email || '';
    document.getElementById('studentPhone').value = student.phone || '';
    document.getElementById('parentContact').value = student.parentContact || '';
    document.getElementById('studentStatus').value = student.status || 'Active';
    document.getElementById('existingFaceDescriptor').value = student.faceDescriptor ? JSON.stringify(student.faceDescriptor) : '';
    document.getElementById('existingFaceImageUrl').value = student.faceImageUrl || '';
    document.getElementById('studentFaceImage').value = '';
    setStudentFacePreview(student.faceImageUrl || '');
    openModal('studentModal');
}

async function deleteStudent(studentId) {
    try {
        if (!window.confirm('Delete this student record?')) {
            return;
        }

        const response = await fetch(`${CONFIG.API_BASE}/students.php?id=${encodeURIComponent(studentId)}`, { method: 'DELETE' });
        const payload = await response.json();
        if (!response.ok || payload.success === false) {
            throw new Error(payload.message || 'Unable to delete student.');
        }

        await loadStudents();
        await loadDashboardData();
        showToast('Student deleted successfully.');
    } catch (error) {
        handleUiError(error);
    }
}

async function saveStudent() {
    try {
        const payload = {
            id: Number(document.getElementById('studentRecordId').value || 0),
            studentCode: document.getElementById('studentId').value.trim(),
            fullName: document.getElementById('studentName').value.trim(),
            className: document.getElementById('studentClass').value,
            rollNumber: document.getElementById('rollNumber').value.trim(),
            email: document.getElementById('studentEmail').value.trim(),
            phone: document.getElementById('studentPhone').value.trim(),
            parentContact: document.getElementById('parentContact').value.trim(),
            status: document.getElementById('studentStatus').value,
            existingFaceDescriptor: document.getElementById('existingFaceDescriptor').value,
            existingFaceImageUrl: document.getElementById('existingFaceImageUrl').value
        };

        if (!payload.studentCode || !payload.fullName) {
            showToast('Student ID and full name are required.', 'error');
            return;
        }

        const faceFile = document.getElementById('studentFaceImage').files[0];
        if (faceFile) {
            const faceData = await buildFaceDescriptorFromFile(faceFile);
            payload.faceDescriptor = faceData.descriptor;
            payload.faceImageBase64 = faceData.imageDataUrl;
        }

        await apiRequest('students.php', {
            method: 'POST',
            body: payload
        });

        closeModal('studentModal');
        await loadStudents();
        await loadDashboardData();
        updateRecognitionSummary();
        showToast('Student saved successfully.');
    } catch (error) {
        handleUiError(error);
    }
}

async function saveSettings() {
    try {
        const payload = {
            institution_name: document.getElementById('institutionName').value.trim(),
            device_id: document.getElementById('dashboardDevice').value.trim(),
            wifi_ssid: document.getElementById('wifiSSID').value.trim(),
            wifi_password: document.getElementById('wifiPassword').value,
            telegram_bot_token: document.getElementById('telegramToken').value.trim(),
            telegram_chat_id: document.getElementById('chatID').value.trim(),
            ai_api_key: document.getElementById('aiAPIKey').value.trim(),
            face_model_url: document.getElementById('faceModelUrl').value.trim(),
            recognition_threshold: (Number(document.getElementById('threshold').value || 48) / 100).toFixed(2),
            unknown_alert_cooldown_seconds: document.getElementById('unknownAlertCooldown').value || '30',
            server_recognition_model: document.getElementById('serverRecognitionModel').value.trim(),
            server_recognition_max_candidates: document.getElementById('serverRecognitionMaxCandidates').value || '8',
            esp32_api_token: document.getElementById('esp32ApiToken').value.trim(),
            notify_telegram: document.getElementById('notifyTelegram').checked ? '1' : '0',
            notify_alerts: document.getElementById('notifyAlerts').checked ? '1' : '0',
            daily_report_enabled: document.getElementById('dailyReport').checked ? '1' : '0'
        };

        const previousModelUrl = state.settings.face_model_url;
        const response = await apiRequest('settings.php', {
            method: 'POST',
            body: payload
        });

        state.settings = { ...DEFAULT_SETTINGS, ...(response.settings || payload) };
        applySettingsToForm();
        updateThresholdDisplay();
        rebuildFaceMatcher();

        if (previousModelUrl !== state.settings.face_model_url) {
            state.recognition.modelsLoaded = false;
            state.recognition.matcher = null;
            stopRecognition();
        }

        showToast('Settings saved successfully.');
    } catch (error) {
        handleUiError(error);
    }
}

function resetSettings() {
    if (!window.confirm('Reset settings to recommended defaults?')) {
        return;
    }

    state.settings = { ...DEFAULT_SETTINGS };
    applySettingsToForm();
    updateThresholdDisplay();
    showToast('Default settings loaded. Click Save Settings to keep them.');
}

function navigateTo(page) {
    document.querySelectorAll('.nav-item').forEach((item) => {
        item.classList.toggle('active', item.dataset.page === page);
    });

    document.querySelectorAll('.page-content').forEach((section) => {
        section.classList.remove('active');
    });

    document.getElementById(`${page}Page`)?.classList.add('active');
    document.getElementById('pageTitle').textContent = {
        dashboard: 'Dashboard',
        recognition: 'Recognition',
        daily: 'Daily Report',
        weekly: 'Weekly Report',
        monthly: 'Monthly Report',
        alerts: 'Alerts',
        students: 'Students',
        settings: 'Settings'
    }[page] || 'Dashboard';

    if (page !== 'recognition') {
        stopRecognition();
    }

    state.currentPage = page;
    document.querySelector('.sidebar')?.classList.remove('active');
    loadPageData(page).catch((error) => {
        console.error(error);
        showToast(error.message || 'Unable to load page data.', 'error');
    });
}

async function loadPageData(page, silentToast = false) {
    if (page === 'dashboard') {
        await loadDashboardData();
    }
    if (page === 'recognition') {
        updateRecognitionSummary();
    }
    if (page === 'daily') {
        await loadDailyReport();
    }
    if (page === 'weekly') {
        await loadWeeklyReport();
    }
    if (page === 'monthly') {
        await loadMonthlyReport();
    }
    if (page === 'alerts') {
        await loadAlerts();
    }
    if (page === 'students') {
        applyStudentFilters();
    }
    if (!silentToast && page !== 'recognition') {
        updateRecognitionSummary();
    }
}

function updateRecognitionSummary() {
    const enrolledCount = state.students.filter((student) => student.faceEnrolled).length;
    setText('recognitionEnrolledCount', enrolledCount);
    setText('recognitionTodayCount', state.dashboardStats?.todayPresent || 0);
    setText('recognitionUnknownCount', state.dashboardStats?.todayAlerts || 0);
    setText('recognitionThresholdDisplay', (parseFloat(state.settings.recognition_threshold || '0.48')).toFixed(2));
}

async function ensureFaceModelsLoaded(forceReload = false) {
    if (state.recognition.modelsLoaded && !forceReload) {
        return;
    }

    if (!window.faceapi) {
        throw new Error('Face recognition library failed to load. Check your internet connection or CDN access.');
    }

    const modelUrl = state.settings.face_model_url || DEFAULT_SETTINGS.face_model_url;
    setRecognitionStatus('Loading face recognition models...');

    await Promise.all([
        faceapi.nets.tinyFaceDetector.loadFromUri(modelUrl),
        faceapi.nets.faceLandmark68Net.loadFromUri(modelUrl),
        faceapi.nets.faceRecognitionNet.loadFromUri(modelUrl)
    ]);

    state.recognition.modelsLoaded = true;
    rebuildFaceMatcher();
    setRecognitionStatus('Face models loaded successfully.');
}

function rebuildFaceMatcher() {
    if (!window.faceapi || !state.recognition.modelsLoaded) {
        state.recognition.matcher = null;
        return;
    }

    const labeledDescriptors = state.students
        .filter((student) => student.faceEnrolled && Array.isArray(student.faceDescriptor) && student.faceDescriptor.length)
        .map((student) => {
            const descriptor = new Float32Array(student.faceDescriptor);
            return new faceapi.LabeledFaceDescriptors(student.studentCode, [descriptor]);
        });

    state.recognition.matcher = labeledDescriptors.length
        ? new faceapi.FaceMatcher(labeledDescriptors, parseFloat(state.settings.recognition_threshold || '0.48'))
        : null;
}

async function buildFaceDescriptorFromFile(file) {
    await ensureFaceModelsLoaded();
    const imageDataUrl = await readFileAsDataUrl(file);
    const imageElement = await createImageElement(imageDataUrl);
    const detection = await faceapi
        .detectSingleFace(imageElement, new faceapi.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.5 }))
        .withFaceLandmarks()
        .withFaceDescriptor();

    if (!detection) {
        throw new Error('No clear front-facing face was found in the selected image.');
    }

    return {
        descriptor: Array.from(detection.descriptor),
        imageDataUrl
    };
}

async function startRecognition() {
    await ensureFaceModelsLoaded();

    if (!state.recognition.matcher) {
        throw new Error('Enroll at least one student with a face photo before starting recognition.');
    }

    const video = document.getElementById('cameraVideo');
    const placeholder = document.getElementById('cameraPlaceholder');

    state.recognition.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user' },
        audio: false
    });

    video.srcObject = state.recognition.stream;
    await video.play();
    placeholder.style.display = 'none';
    resizeRecognitionCanvas();

    state.recognition.isRunning = true;
    setRecognitionBadge('Running');
    setRecognitionStatus('Camera started. Looking for faces...');

    clearInterval(state.recognition.intervalId);
    state.recognition.intervalId = setInterval(scanRecognitionFrame, CONFIG.RECOGNITION_SCAN_INTERVAL);
    await scanRecognitionFrame();
}

function stopRecognition() {
    clearInterval(state.recognition.intervalId);
    state.recognition.intervalId = null;

    if (state.recognition.stream) {
        state.recognition.stream.getTracks().forEach((track) => track.stop());
        state.recognition.stream = null;
    }

    const video = document.getElementById('cameraVideo');
    if (video) {
        video.srcObject = null;
    }

    const placeholder = document.getElementById('cameraPlaceholder');
    if (placeholder) {
        placeholder.style.display = 'flex';
    }

    clearRecognitionOverlay();
    state.recognition.isRunning = false;
    state.recognition.isBusy = false;
    setRecognitionBadge('Idle');
    setRecognitionStatus('Recognition stopped.');
}

async function scanRecognitionFrame() {
    if (!state.recognition.isRunning || state.recognition.isBusy || !state.recognition.matcher) {
        return;
    }

    const video = document.getElementById('cameraVideo');
    if (!video || video.readyState < 2) {
        return;
    }

    state.recognition.isBusy = true;

    try {
        resizeRecognitionCanvas();
        const detection = await faceapi
            .detectSingleFace(video, new faceapi.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.5 }))
            .withFaceLandmarks()
            .withFaceDescriptor();

        if (!detection) {
            clearRecognitionOverlay();
            setRecognitionStatus('No face detected in the camera frame.');
            return;
        }

        const match = state.recognition.matcher.findBestMatch(detection.descriptor);
        const snapshotBase64 = captureRecognitionSnapshot();
        const similarity = Number(Math.max(0, 1 - match.distance).toFixed(4));

        if (match.label !== 'unknown') {
            const student = state.students.find((item) => item.studentCode === match.label);
            drawRecognitionOverlay(detection, `${student?.fullName || match.label} ${(similarity * 100).toFixed(0)}%`, true);

            if (!student) {
                setRecognitionStatus('Face matched a saved label, but the student record is missing.');
                return;
            }

            const lastSeen = state.recognition.lastRecognizedAt[student.studentCode] || 0;
            if (Date.now() - lastSeen < CONFIG.RECOGNITION_COOLDOWN_MS) {
                setRecognitionStatus(`Recently processed ${student.fullName}. Waiting before scanning again.`);
                return;
            }

            const response = await apiRequest('attendance.php', {
                method: 'POST',
                body: {
                    status: 'Present',
                    studentCode: student.studentCode,
                    studentName: student.fullName,
                    confidence: similarity,
                    deviceId: state.settings.device_id || DEFAULT_SETTINGS.device_id,
                    source: 'dashboard-face-recognition',
                    snapshotBase64,
                    reason: 'Automatic face recognition match'
                }
            });

            state.recognition.lastRecognizedAt[student.studentCode] = Date.now();
            appendRecognitionFeed({
                type: response.duplicate ? 'alert' : 'present',
                title: student.fullName,
                details: response.duplicate ? 'Attendance already marked for today' : `Attendance recorded for ${student.studentCode}`,
                meta: `${(similarity * 100).toFixed(0)}% match`
            });
            setRecognitionStatus(response.message);
            await refreshAfterRecognition();
            return;
        }

        drawRecognitionOverlay(detection, 'Unknown person', false);
        const cooldownMs = Number(state.settings.unknown_alert_cooldown_seconds || '30') * 1000;
        if (Date.now() - state.recognition.lastUnknownAt < cooldownMs) {
            setRecognitionStatus('Unknown face detected, but alert delivery is still in cooldown.');
            return;
        }

        const response = await apiRequest('attendance.php', {
            method: 'POST',
            body: {
                status: 'Unknown',
                studentName: 'Unknown Person',
                confidence: similarity,
                deviceId: state.settings.device_id || DEFAULT_SETTINGS.device_id,
                source: 'dashboard-face-recognition',
                snapshotBase64,
                reason: 'Unknown person detected by dashboard camera'
            }
        });

        state.recognition.lastUnknownAt = Date.now();
        appendRecognitionFeed({
            type: 'alert',
            title: 'Unknown person',
            details: response.message,
            meta: `${(similarity * 100).toFixed(0)}% confidence`
        });
        setRecognitionStatus(response.message);
        await refreshAfterRecognition();
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Recognition scan failed.', 'error');
        setRecognitionStatus(error.message || 'Recognition scan failed.');
    } finally {
        state.recognition.isBusy = false;
    }
}

async function refreshAfterRecognition() {
    await loadDashboardData();
    await loadStudents();
    if (state.currentPage === 'daily') {
        await loadDailyReport();
    }
    if (state.currentPage === 'alerts') {
        await loadAlerts();
    }
}

function resizeRecognitionCanvas() {
    const video = document.getElementById('cameraVideo');
    const canvas = document.getElementById('cameraOverlay');
    if (!video || !canvas || !video.videoWidth || !video.videoHeight) {
        return;
    }
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
}

function drawRecognitionOverlay(detection, label, isMatch) {
    const canvas = document.getElementById('cameraOverlay');
    const context = canvas.getContext('2d');
    const box = detection.detection.box;
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.strokeStyle = isMatch ? CONFIG.CHART_COLORS.success : CONFIG.CHART_COLORS.danger;
    context.lineWidth = 3;
    context.strokeRect(box.x, box.y, box.width, box.height);
    context.fillStyle = context.strokeStyle;
    context.fillRect(box.x, Math.max(box.y - 28, 0), Math.max(box.width, 180), 28);
    context.fillStyle = '#ffffff';
    context.font = '16px Inter, sans-serif';
    context.fillText(label, box.x + 8, Math.max(box.y - 10, 18));
}

function clearRecognitionOverlay() {
    const canvas = document.getElementById('cameraOverlay');
    const context = canvas.getContext('2d');
    context.clearRect(0, 0, canvas.width, canvas.height);
}

function captureRecognitionSnapshot() {
    const video = document.getElementById('cameraVideo');
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.85);
}

function appendRecognitionFeed(entry) {
    const container = document.getElementById('recognitionFeed');
    const item = document.createElement('div');
    item.className = `feed-item ${entry.type}`;
    item.innerHTML = `
        <h4>${escapeHtml(entry.title)}</h4>
        <p>${escapeHtml(entry.details)}</p>
        <p>${escapeHtml(entry.meta)} - ${formatShortTimestamp(new Date().toISOString())}</p>
    `;
    container.prepend(item);

    while (container.children.length > 12) {
        container.removeChild(container.lastChild);
    }
}

function clearRecognitionFeed() {
    document.getElementById('recognitionFeed').innerHTML = '';
}

function setRecognitionStatus(message) {
    document.getElementById('recognitionStatusText').textContent = message;
}

function setRecognitionBadge(label) {
    document.getElementById('recognitionStateLabel').textContent = label;
}

async function handleStudentFaceSelection(event) {
    const file = event.target.files[0];
    if (!file) {
        setStudentFacePreview('');
        return;
    }

    const imageDataUrl = await readFileAsDataUrl(file);
    setStudentFacePreview(imageDataUrl);
}

function setStudentFacePreview(imageUrl) {
    const image = document.getElementById('studentFacePreview');
    const emptyState = document.getElementById('studentFaceEmpty');
    if (imageUrl) {
        image.src = imageUrl;
        image.style.display = 'block';
        emptyState.style.display = 'none';
    } else {
        image.src = '';
        image.style.display = 'none';
        emptyState.style.display = 'block';
    }
}

function openModal(modalId) {
    document.getElementById(modalId)?.classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId)?.classList.remove('active');
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    const icon = toast.querySelector('i');
    document.getElementById('toastMessage').textContent = message;
    icon.className = type === 'error' ? 'fas fa-exclamation-circle' : 'fas fa-check-circle';
    icon.style.color = type === 'error' ? CONFIG.CHART_COLORS.danger : CONFIG.CHART_COLORS.success;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3200);
}

function setCurrentDate() {
    const today = new Date();
    document.getElementById('dailyDate').value = toInputDate(today);
    const weekStart = getWeekStart(today);
    const weekEnd = getWeekEnd(today);
    document.getElementById('weekStart').value = toInputDate(weekStart);
    document.getElementById('weekEnd').value = toInputDate(weekEnd);
    document.getElementById('monthSelect').value = String(today.getMonth() + 1);
}

function populateYearOptions() {
    const currentYear = new Date().getFullYear();
    const yearSelect = document.getElementById('yearSelect');
    yearSelect.innerHTML = '';
    for (let year = currentYear - 1; year <= currentYear + 1; year += 1) {
        const option = document.createElement('option');
        option.value = String(year);
        option.textContent = String(year);
        if (year === currentYear) {
            option.selected = true;
        }
        yearSelect.appendChild(option);
    }
}

function startAutoRefresh() {
    state.autoRefreshTimer = setInterval(() => {
        if (state.currentPage === 'dashboard') {
            loadDashboardData().catch((error) => console.error(error));
        }
    }, CONFIG.REFRESH_INTERVAL);
}

function showImageModal(image) {
    const modal = document.createElement('div');
    modal.className = 'modal active';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 640px;">
            <div class="modal-header">
                <h3>Flagged Image</h3>
                <button class="close-btn">&times;</button>
            </div>
            <div class="modal-body">
                <img src="${image.url}" alt="Flagged image" style="width: 100%; border-radius: 8px;">
                <p style="margin-top: 1rem;"><strong>Reason:</strong> ${escapeHtml(image.reason)}</p>
                <p><strong>Captured:</strong> ${formatFullTimestamp(image.time)}</p>
            </div>
        </div>
    `;
    modal.addEventListener('click', (event) => {
        if (event.target === modal || event.target.classList.contains('close-btn')) {
            modal.remove();
        }
    });
    document.body.appendChild(modal);
}

function exportDailyReport() { window.print(); }
function printDailyReport() { window.print(); }
function fetchWeeklyReport() { loadWeeklyReport().catch((error) => showToast(error.message, 'error')); }
function exportWeeklyReport() { showToast('Use the browser print dialog to save the weekly view as PDF.'); }
function fetchMonthlyReport() { loadMonthlyReport().catch((error) => showToast(error.message, 'error')); }
function exportMonthlyReport() { showToast('Use the browser print dialog to save the monthly view as PDF.'); }
function importStudents() { showToast('CSV import is not added yet. Use Add Student for face enrollment.', 'error'); }
function exportStudents() { showToast('Student export can be added next if you want CSV download.'); }

function debounce(callback, delay) {
    let timer = null;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => callback(...args), delay);
    };
}

function getWeekStart(date) {
    const workingDate = new Date(date);
    const day = workingDate.getDay();
    const diff = workingDate.getDate() - day + (day === 0 ? -6 : 1);
    workingDate.setDate(diff);
    return workingDate;
}

function getWeekEnd(date) {
    const weekStart = getWeekStart(date);
    const workingDate = new Date(weekStart);
    workingDate.setDate(workingDate.getDate() + 6);
    return workingDate;
}

function toInputDate(value) {
    return new Date(value.getTime() - value.getTimezoneOffset() * 60000).toISOString().split('T')[0];
}

function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('Unable to read the selected file.'));
        reader.readAsDataURL(file);
    });
}

function createImageElement(src) {
    return new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error('Unable to load the selected image.'));
        image.src = src;
    });
}

function formatShortTimestamp(value) {
    if (!value) return '-';
    const date = new Date(value);
    return date.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

function formatFullTimestamp(value) {
    return value ? new Date(value).toLocaleString() : '-';
}

function formatTimeOnly(value) {
    if (!value) return '-';
    return new Date(value).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', second: '2-digit' });
}

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
}

function setText(elementId, value) {
    const element = document.getElementById(elementId);
    if (element) {
        element.textContent = String(value);
    }
}

function handleUiError(error) {
    console.error(error);
    showToast(error.message || 'Something went wrong.', 'error');
}
