<?php

declare(strict_types=1);

return [
    'db' => [
        'host' => getenv('ATTENDANCE_DB_HOST') ?: '127.0.0.1',
        'port' => (int) (getenv('ATTENDANCE_DB_PORT') ?: 3306),
        'name' => getenv('ATTENDANCE_DB_NAME') ?: 'student_attendance_system',
        'user' => getenv('ATTENDANCE_DB_USER') ?: 'root',
        'pass' => getenv('ATTENDANCE_DB_PASS') !== false ? getenv('ATTENDANCE_DB_PASS') : '',
    ],
    'app' => [
        'timezone' => getenv('ATTENDANCE_APP_TIMEZONE') ?: 'Asia/Kolkata',
        'default_device_id' => getenv('ATTENDANCE_DEVICE_ID') ?: 'CAM-001',
    ],
];
