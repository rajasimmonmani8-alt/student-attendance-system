<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
        json_response([
            'success' => true,
            'settings' => load_settings(),
        ]);
    }

    $payload = request_data();
    $allowedKeys = [
        'institution_name',
        'device_id',
        'wifi_ssid',
        'wifi_password',
        'telegram_bot_token',
        'telegram_chat_id',
        'ai_api_key',
        'recognition_threshold',
        'unknown_alert_cooldown_seconds',
        'face_model_url',
        'server_recognition_model',
        'server_recognition_max_candidates',
        'esp32_api_token',
        'notify_telegram',
        'notify_alerts',
        'daily_report_enabled',
    ];

    $settingsToSave = [];
    foreach ($allowedKeys as $key) {
        if (array_key_exists($key, $payload)) {
            $settingsToSave[$key] = $payload[$key];
        }
    }

    save_settings($settingsToSave);

    json_response([
        'success' => true,
        'message' => 'Settings saved successfully.',
        'settings' => load_settings(),
    ]);
} catch (Throwable $exception) {
    fail_response('Unable to load or save settings.', 500, [
        'details' => $exception->getMessage(),
    ]);
}
