<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

function fetch_alerts(string $filter, string $dateFilter): array
{
    $conditions = [];
    $params = [];

    if ($filter === 'resolved') {
        $conditions[] = 'a.resolved = 1';
    } elseif ($filter === 'unresolved') {
        $conditions[] = 'a.resolved = 0';
    }

    if ($dateFilter !== '') {
        $conditions[] = 'DATE(a.created_at) = :date_filter';
        $params['date_filter'] = $dateFilter;
    }

    $whereSql = $conditions === [] ? '' : 'WHERE ' . implode(' AND ', $conditions);

    $statement = db()->prepare(
        "SELECT a.*, attendance.attendance_time
         FROM alerts a
         LEFT JOIN attendance_logs attendance ON attendance.id = a.attendance_log_id
         {$whereSql}
         ORDER BY a.created_at DESC"
    );
    $statement->execute($params);

    return array_map(static function (array $row): array {
        return [
            'id' => (int) $row['id'],
            'alertCode' => $row['alert_code'],
            'time' => $row['created_at'],
            'studentId' => $row['student_label'],
            'reason' => $row['reason'],
            'image' => $row['image_path'],
            'device' => $row['device_id'],
            'telegramSent' => (bool) $row['telegram_sent'],
            'resolved' => (bool) $row['resolved'],
            'resolutionNotes' => $row['resolution_notes'],
        ];
    }, $statement->fetchAll());
}

try {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        $filter = (string) query_value('filter', 'all');
        $dateFilter = (string) query_value('date', '');

        json_response([
            'success' => true,
            'alerts' => fetch_alerts($filter, $dateFilter),
        ]);
    }

    $payload = request_data();
    $action = (string) ($payload['action'] ?? '');

    if ($action === 'resolve') {
        $statement = db()->prepare(
            "UPDATE alerts
             SET resolved = 1,
                 resolution_notes = :resolution_notes,
                 resolved_at = NOW()
             WHERE id = :id"
        );
        $statement->execute([
            'id' => (int) ($payload['id'] ?? 0),
            'resolution_notes' => trim((string) ($payload['resolutionNotes'] ?? '')),
        ]);

        json_response([
            'success' => true,
            'message' => 'Alert resolved successfully.',
            'alerts' => fetch_alerts('all', ''),
        ]);
    }

    if ($action === 'clear_all') {
        db()->exec('DELETE FROM alerts');

        json_response([
            'success' => true,
            'message' => 'All alerts cleared successfully.',
            'alerts' => [],
        ]);
    }

    fail_response('Unsupported alert action.', 422);
} catch (Throwable $exception) {
    fail_response('Unable to process alert request.', 500, [
        'details' => $exception->getMessage(),
    ]);
}
