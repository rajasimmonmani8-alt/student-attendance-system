<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

function active_students_count(): int
{
    return (int) db()->query("SELECT COUNT(*) FROM students WHERE status = 'Active'")->fetchColumn();
}

function daily_report(string $date): array
{
    $activeStudents = active_students_count();

    $presentStatement = db()->prepare(
        "SELECT COUNT(DISTINCT student_id)
         FROM attendance_logs
         WHERE attendance_status = 'Present'
           AND attendance_date = :attendance_date"
    );
    $presentStatement->execute(['attendance_date' => $date]);
    $present = (int) $presentStatement->fetchColumn();
    $absent = max($activeStudents - $present, 0);
    $rate = $activeStudents > 0 ? round(($present / $activeStudents) * 100, 1) : 0;

    $peakStatement = db()->prepare(
        "SELECT DATE_FORMAT(attendance_time, '%h:00 %p') AS peak_hour, COUNT(*) AS hits
         FROM attendance_logs
         WHERE attendance_date = :attendance_date
         GROUP BY HOUR(attendance_time)
         ORDER BY hits DESC, HOUR(attendance_time) ASC
         LIMIT 1"
    );
    $peakStatement->execute(['attendance_date' => $date]);
    $peakHour = $peakStatement->fetchColumn() ?: '-';

    $hourlyStatement = db()->prepare(
        "SELECT HOUR(attendance_time) AS hour_number, COUNT(*) AS hits
         FROM attendance_logs
         WHERE attendance_date = :attendance_date
         GROUP BY HOUR(attendance_time)"
    );
    $hourlyStatement->execute(['attendance_date' => $date]);
    $hourlyRows = $hourlyStatement->fetchAll();
    $hourMap = [];
    foreach ($hourlyRows as $row) {
        $hourMap[(int) $row['hour_number']] = (int) $row['hits'];
    }

    $hourLabels = [];
    $hourData = [];
    for ($hour = 8; $hour <= 17; $hour++) {
        $hourLabels[] = date('gA', strtotime(sprintf('%02d:00:00', $hour)));
        $hourData[] = $hourMap[$hour] ?? 0;
    }

    $tableStatement = db()->prepare(
        "SELECT attendance_code, attendance_time, student_code, student_name, attendance_status, device_id
         FROM attendance_logs
         WHERE attendance_date = :attendance_date
         ORDER BY attendance_time DESC"
    );
    $tableStatement->execute(['attendance_date' => $date]);

    return [
        'date' => $date,
        'present' => $present,
        'absent' => $absent,
        'rate' => number_format($rate, 1) . '%',
        'peakHour' => $peakHour,
        'hourlyLabels' => $hourLabels,
        'hourlyData' => $hourData,
        'tableData' => array_map(static function (array $row): array {
            return [
                'id' => $row['attendance_code'],
                'time' => $row['attendance_time'],
                'studentId' => $row['student_code'] ?: 'UNKNOWN',
                'name' => $row['student_name'],
                'status' => $row['attendance_status'],
                'device' => $row['device_id'],
            ];
        }, $tableStatement->fetchAll()),
    ];
}

function weekly_report(string $startDate, string $endDate): array
{
    $activeStudents = active_students_count();

    $summaryStatement = db()->prepare(
        "SELECT attendance_date, COUNT(DISTINCT student_id) AS present_count
         FROM attendance_logs
         WHERE attendance_status = 'Present'
           AND attendance_date BETWEEN :start_date AND :end_date
         GROUP BY attendance_date"
    );
    $summaryStatement->execute([
        'start_date' => $startDate,
        'end_date' => $endDate,
    ]);

    $rows = $summaryStatement->fetchAll();
    $presentMap = [];
    foreach ($rows as $row) {
        $presentMap[$row['attendance_date']] = (int) $row['present_count'];
    }

    $labels = [];
    $weeklyData = [];
    $distributionLabels = [];
    $distributionData = [];
    $totalPresent = 0;
    $totalAbsent = 0;
    $bestDay = '-';
    $bestValue = -1;

    $cursor = new DateTimeImmutable($startDate);
    $end = new DateTimeImmutable($endDate);

    while ($cursor <= $end) {
        $date = $cursor->format('Y-m-d');
        $present = $presentMap[$date] ?? 0;
        $absent = max($activeStudents - $present, 0);

        $labels[] = $cursor->format('D');
        $weeklyData[] = $present;
        $distributionLabels[] = $cursor->format('D');
        $distributionData[] = $present;
        $totalPresent += $present;
        $totalAbsent += $absent;

        if ($present > $bestValue) {
            $bestValue = $present;
            $bestDay = $cursor->format('l');
        }

        $cursor = $cursor->modify('+1 day');
    }

    $days = max(count($weeklyData), 1);
    $averageRate = $activeStudents > 0 ? round(($totalPresent / ($activeStudents * $days)) * 100, 1) : 0;

    return [
        'present' => $totalPresent,
        'absent' => $totalAbsent,
        'rate' => number_format($averageRate, 1) . '%',
        'activeDay' => $bestDay,
        'labels' => $labels,
        'weeklyData' => $weeklyData,
        'distributionLabels' => $distributionLabels,
        'distributionData' => $distributionData,
    ];
}

function monthly_report(int $month, int $year): array
{
    $activeStudents = active_students_count();
    $startDate = sprintf('%04d-%02d-01', $year, $month);
    $endDate = (new DateTimeImmutable($startDate))->modify('last day of this month')->format('Y-m-d');

    $summaryStatement = db()->prepare(
        "SELECT attendance_date, COUNT(DISTINCT student_id) AS present_count
         FROM attendance_logs
         WHERE attendance_status = 'Present'
           AND attendance_date BETWEEN :start_date AND :end_date
         GROUP BY attendance_date"
    );
    $summaryStatement->execute([
        'start_date' => $startDate,
        'end_date' => $endDate,
    ]);

    $rows = $summaryStatement->fetchAll();
    $presentMap = [];
    foreach ($rows as $row) {
        $presentMap[$row['attendance_date']] = (int) $row['present_count'];
    }

    $labels = [];
    $dailyData = [];
    $totalPresent = 0;
    $totalAbsent = 0;
    $bestDay = '-';
    $worstDay = '-';
    $bestValue = -1;
    $worstValue = PHP_INT_MAX;

    $cursor = new DateTimeImmutable($startDate);
    $end = new DateTimeImmutable($endDate);

    while ($cursor <= $end) {
        $date = $cursor->format('Y-m-d');
        $present = $presentMap[$date] ?? 0;
        $absent = max($activeStudents - $present, 0);

        $labels[] = $cursor->format('j');
        $dailyData[] = $present;
        $totalPresent += $present;
        $totalAbsent += $absent;

        if ($present > $bestValue) {
            $bestValue = $present;
            $bestDay = $date;
        }

        if ($present < $worstValue) {
            $worstValue = $present;
            $worstDay = $date;
        }

        $cursor = $cursor->modify('+1 day');
    }

    $days = max(count($dailyData), 1);
    $averageRate = $activeStudents > 0 ? round(($totalPresent / ($activeStudents * $days)) * 100, 1) : 0;

    return [
        'present' => $totalPresent,
        'absent' => $totalAbsent,
        'rate' => number_format($averageRate, 1) . '%',
        'bestDay' => $bestDay,
        'worstDay' => $worstDay,
        'labels' => $labels,
        'dailyData' => $dailyData,
    ];
}

try {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        $report = (string) query_value('report', 'daily');

        if ($report === 'weekly') {
            $startDate = (string) query_value('startDate', date('Y-m-d', strtotime('monday this week')));
            $endDate = (string) query_value('endDate', date('Y-m-d', strtotime('sunday this week')));
            json_response([
                'success' => true,
                'report' => weekly_report($startDate, $endDate),
            ]);
        }

        if ($report === 'monthly') {
            $month = (int) query_value('month', date('n'));
            $year = (int) query_value('year', date('Y'));
            json_response([
                'success' => true,
                'report' => monthly_report($month, $year),
            ]);
        }

        $date = (string) query_value('date', date('Y-m-d'));
        json_response([
            'success' => true,
            'report' => daily_report($date),
        ]);
    }

    $payload = request_data();
    $settings = load_settings();
    $status = trim((string) ($payload['status'] ?? 'Unknown'));
    $studentCode = trim((string) ($payload['studentCode'] ?? ''));
    $deviceId = trim((string) ($payload['deviceId'] ?? ($settings['device_id'] ?? 'DASHBOARD-CAM-001')));
    $confidence = as_float($payload['confidence'] ?? 0);
    $snapshotPath = save_base64_image(
        $payload['snapshotBase64'] ?? null,
        strtolower($status) === 'present' ? 'attendance' : 'alerts',
        strtolower($status) === 'present' ? 'attendance' : 'alert'
    );
    $source = trim((string) ($payload['source'] ?? 'dashboard-face-recognition'));
    $today = date('Y-m-d');
    $timestamp = date('Y-m-d H:i:s');

    $student = null;
    if ($studentCode !== '') {
        $studentStatement = db()->prepare('SELECT * FROM students WHERE student_code = :student_code LIMIT 1');
        $studentStatement->execute(['student_code' => $studentCode]);
        $student = $studentStatement->fetch() ?: null;
    }

    if (strcasecmp($status, 'Present') === 0 && $student !== null) {
        if (attendance_day_exists((int) $student['id'], $today)) {
            json_response([
                'success' => true,
                'duplicate' => true,
                'message' => 'Attendance already marked for this student today.',
            ]);
        }

        $statement = db()->prepare(
            "INSERT INTO attendance_logs (
                attendance_code, student_id, student_code, student_name, attendance_status,
                match_confidence, recognition_source, device_id, attendance_date,
                attendance_time, snapshot_path, notes
             ) VALUES (
                :attendance_code, :student_id, :student_code, :student_name, :attendance_status,
                :match_confidence, :recognition_source, :device_id, :attendance_date,
                :attendance_time, :snapshot_path, :notes
             )"
        );
        $statement->execute([
            'attendance_code' => next_code('ATT'),
            'student_id' => (int) $student['id'],
            'student_code' => $student['student_code'],
            'student_name' => $student['full_name'],
            'attendance_status' => 'Present',
            'match_confidence' => $confidence,
            'recognition_source' => $source,
            'device_id' => $deviceId,
            'attendance_date' => $today,
            'attendance_time' => $timestamp,
            'snapshot_path' => $snapshotPath,
            'notes' => trim((string) ($payload['reason'] ?? 'Automatic face recognition match')),
        ]);

        json_response([
            'success' => true,
            'duplicate' => false,
            'message' => 'Attendance recorded successfully.',
        ]);
    }

    $cooldown = max((int) ($settings['unknown_alert_cooldown_seconds'] ?? 30), 5);
    $cooldownBoundary = date('Y-m-d H:i:s', time() - $cooldown);
    $recentAlertStatement = db()->prepare(
        'SELECT id
         FROM alerts
         WHERE device_id = :device_id
           AND created_at >= :cooldown_boundary
         ORDER BY created_at DESC
         LIMIT 1'
    );
    $recentAlertStatement->execute([
        'device_id' => $deviceId,
        'cooldown_boundary' => $cooldownBoundary,
    ]);
    $suppressed = (bool) $recentAlertStatement->fetchColumn();

    $studentLabel = $student['full_name'] ?? trim((string) ($payload['studentName'] ?? 'Unknown Person'));
    $reason = trim((string) ($payload['reason'] ?? 'Unknown person detected by face recognition.'));

    $attendanceStatement = db()->prepare(
        "INSERT INTO attendance_logs (
            attendance_code, student_id, student_code, student_name, attendance_status,
            match_confidence, recognition_source, device_id, attendance_date,
            attendance_time, snapshot_path, notes
         ) VALUES (
            :attendance_code, :student_id, :student_code, :student_name, :attendance_status,
            :match_confidence, :recognition_source, :device_id, :attendance_date,
            :attendance_time, :snapshot_path, :notes
         )"
    );
    $attendanceStatement->execute([
        'attendance_code' => next_code('ATT'),
        'student_id' => $student['id'] ?? null,
        'student_code' => $student['student_code'] ?? null,
        'student_name' => $studentLabel,
        'attendance_status' => 'Alert',
        'match_confidence' => $confidence,
        'recognition_source' => $source,
        'device_id' => $deviceId,
        'attendance_date' => $today,
        'attendance_time' => $timestamp,
        'snapshot_path' => $snapshotPath,
        'notes' => $reason,
    ]);
    $attendanceLogId = (int) db()->lastInsertId();

    if ($suppressed) {
        json_response([
            'success' => true,
            'suppressed' => true,
            'message' => 'Unknown face detected, but alert delivery is in cooldown.',
        ]);
    }

    $alertCode = next_code('ALT');
    $telegramSent = false;
    if (as_bool($settings['notify_alerts'] ?? '0')) {
        $caption = sprintf(
            "Unknown person detected\nDevice: %s\nTime: %s\nReason: %s",
            $deviceId,
            $timestamp,
            $reason
        );
        $telegramSent = send_telegram_photo($snapshotPath, $caption, $settings);
    }

    $alertStatement = db()->prepare(
        "INSERT INTO alerts (
            alert_code, attendance_log_id, student_id, student_label, reason,
            image_path, device_id, telegram_sent
         ) VALUES (
            :alert_code, :attendance_log_id, :student_id, :student_label, :reason,
            :image_path, :device_id, :telegram_sent
         )"
    );
    $alertStatement->execute([
        'alert_code' => $alertCode,
        'attendance_log_id' => $attendanceLogId,
        'student_id' => $student['id'] ?? null,
        'student_label' => $studentLabel,
        'reason' => $reason,
        'image_path' => $snapshotPath,
        'device_id' => $deviceId,
        'telegram_sent' => $telegramSent ? 1 : 0,
    ]);

    json_response([
        'success' => true,
        'suppressed' => false,
        'message' => $telegramSent
            ? 'Unknown person alert sent to Telegram.'
            : 'Unknown person saved as an alert.',
    ]);
} catch (Throwable $exception) {
    fail_response('Unable to process attendance request.', 500, [
        'details' => $exception->getMessage(),
    ]);
}
