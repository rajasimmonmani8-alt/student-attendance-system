<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        fail_response('Only POST is allowed for ESP32 attendance.', 405);
    }

    $settings = load_settings();
    $apiToken = trim((string) ($_POST['api_token'] ?? ''));
    $expectedToken = trim((string) ($settings['esp32_api_token'] ?? ''));

    if ($expectedToken !== '' && !hash_equals($expectedToken, $apiToken)) {
        fail_response('Invalid ESP32 API token.', 401);
    }

    $deviceId = trim((string) ($_POST['device_id'] ?? ($settings['device_id'] ?? 'ESP32-CAM-001')));
    $file = $_FILES['photo'] ?? $_FILES['image'] ?? null;
    if (!is_array($file)) {
        fail_response('Image file is required.', 422);
    }

    $snapshotPath = save_uploaded_image($file, 'attendance', 'esp32');
    if ($snapshotPath === null) {
        fail_response('Unable to save uploaded ESP32 image.', 500);
    }

    $recognition = recognize_student_from_image($snapshotPath, $settings);
    $today = date('Y-m-d');
    $timestamp = date('Y-m-d H:i:s');
    $source = 'esp32-cam-server-recognition';

    $matchedStudent = null;
    if (!empty($recognition['student_code'])) {
        $studentStatement = db()->prepare(
            "SELECT *
             FROM students
             WHERE student_code = :student_code
               AND status = 'Active'
             LIMIT 1"
        );
        $studentStatement->execute([
            'student_code' => (string) $recognition['student_code'],
        ]);
        $matchedStudent = $studentStatement->fetch() ?: null;
    }

    if (($recognition['matched'] ?? false) && $matchedStudent !== null) {
        if (attendance_day_exists((int) $matchedStudent['id'], $today)) {
            json_response([
                'success' => true,
                'recognized' => true,
                'duplicate' => true,
                'studentCode' => $matchedStudent['student_code'],
                'studentName' => $matchedStudent['full_name'],
                'message' => 'Attendance already exists for this student today.',
            ]);
        }

        $statement = db()->prepare(
            "INSERT INTO attendance_logs (
                attendance_code, student_id, student_code, student_name, attendance_status,
                match_confidence, recognition_source, device_id, attendance_date,
                attendance_time, snapshot_path, notes
             ) VALUES (
                :attendance_code, :student_id, :student_code, :student_name, :attendance_status,
                :match_confidence, :recognition_source, :device_id, :attendance_date,
                :attendance_time, :snapshot_path, :notes
             )"
        );
        $statement->execute([
            'attendance_code' => next_code('ATT'),
            'student_id' => (int) $matchedStudent['id'],
            'student_code' => $matchedStudent['student_code'],
            'student_name' => $matchedStudent['full_name'],
            'attendance_status' => 'Present',
            'match_confidence' => as_float($recognition['confidence'] ?? 0),
            'recognition_source' => $source,
            'device_id' => $deviceId,
            'attendance_date' => $today,
            'attendance_time' => $timestamp,
            'snapshot_path' => $snapshotPath,
            'notes' => trim((string) ($recognition['reason'] ?? 'ESP32-CAM server-side face match')),
        ]);

        json_response([
            'success' => true,
            'recognized' => true,
            'duplicate' => false,
            'studentCode' => $matchedStudent['student_code'],
            'studentName' => $matchedStudent['full_name'],
            'confidence' => as_float($recognition['confidence'] ?? 0),
            'message' => 'Attendance recorded from ESP32-CAM image.',
        ]);
    }

    $cooldown = max((int) ($settings['unknown_alert_cooldown_seconds'] ?? 30), 5);
    $cooldownBoundary = date('Y-m-d H:i:s', time() - $cooldown);
    $recentAlertStatement = db()->prepare(
        'SELECT id
         FROM alerts
         WHERE device_id = :device_id
           AND created_at >= :cooldown_boundary
         ORDER BY created_at DESC
         LIMIT 1'
    );
    $recentAlertStatement->execute([
        'device_id' => $deviceId,
        'cooldown_boundary' => $cooldownBoundary,
    ]);
    $suppressed = (bool) $recentAlertStatement->fetchColumn();

    $reason = trim((string) ($recognition['reason'] ?? 'Unknown person detected by ESP32-CAM.'));
    $studentLabel = trim((string) ($recognition['student_name'] ?? 'Unknown Person'));

    $attendanceStatement = db()->prepare(
        "INSERT INTO attendance_logs (
            attendance_code, student_id, student_code, student_name, attendance_status,
            match_confidence, recognition_source, device_id, attendance_date,
            attendance_time, snapshot_path, notes
         ) VALUES (
            :attendance_code, :student_id, :student_code, :student_name, :attendance_status,
            :match_confidence, :recognition_source, :device_id, :attendance_date,
            :attendance_time, :snapshot_path, :notes
         )"
    );
    $attendanceStatement->execute([
        'attendance_code' => next_code('ATT'),
        'student_id' => null,
        'student_code' => null,
        'student_name' => $studentLabel,
        'attendance_status' => 'Alert',
        'match_confidence' => as_float($recognition['confidence'] ?? 0),
        'recognition_source' => $source,
        'device_id' => $deviceId,
        'attendance_date' => $today,
        'attendance_time' => $timestamp,
        'snapshot_path' => $snapshotPath,
        'notes' => $reason,
    ]);
    $attendanceLogId = (int) db()->lastInsertId();

    if ($suppressed) {
        json_response([
            'success' => true,
            'recognized' => false,
            'suppressed' => true,
            'message' => 'Unknown person detected, but alert delivery is in cooldown.',
        ]);
    }

    $telegramSent = false;
    if (as_bool($settings['notify_alerts'] ?? '0')) {
        $caption = sprintf(
            "Unknown person detected by ESP32-CAM\nDevice: %s\nTime: %s\nReason: %s",
            $deviceId,
            $timestamp,
            $reason
        );
        $telegramSent = send_telegram_photo($snapshotPath, $caption, $settings);
    }

    $alertStatement = db()->prepare(
        "INSERT INTO alerts (
            alert_code, attendance_log_id, student_id, student_label, reason,
            image_path, device_id, telegram_sent
         ) VALUES (
            :alert_code, :attendance_log_id, :student_id, :student_label, :reason,
            :image_path, :device_id, :telegram_sent
         )"
    );
    $alertStatement->execute([
        'alert_code' => next_code('ALT'),
        'attendance_log_id' => $attendanceLogId,
        'student_id' => null,
        'student_label' => $studentLabel,
        'reason' => $reason,
        'image_path' => $snapshotPath,
        'device_id' => $deviceId,
        'telegram_sent' => $telegramSent ? 1 : 0,
    ]);

    json_response([
        'success' => true,
        'recognized' => false,
        'suppressed' => false,
        'message' => $telegramSent
            ? 'Unknown person alert sent to Telegram.'
            : 'Unknown person saved as an alert.',
    ]);
} catch (Throwable $exception) {
    fail_response('Unable to process ESP32 attendance request.', 500, [
        'details' => $exception->getMessage(),
    ]);
}
