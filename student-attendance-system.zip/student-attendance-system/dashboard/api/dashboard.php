<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

function dashboard_week_chart(int $activeStudents): array
{
    $statement = db()->query(
        "SELECT attendance_date, COUNT(*) AS present_count
         FROM attendance_logs
         WHERE attendance_status = 'Present'
           AND attendance_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
         GROUP BY attendance_date"
    );

    $presentMap = [];
    foreach ($statement->fetchAll() as $row) {
        $presentMap[$row['attendance_date']] = (int) $row['present_count'];
    }

    $labels = [];
    $present = [];
    $absent = [];
    for ($offset = 6; $offset >= 0; $offset--) {
        $date = date('Y-m-d', strtotime('-' . $offset . ' day'));
        $dayPresent = $presentMap[$date] ?? 0;
        $labels[] = date('D', strtotime($date));
        $present[] = $dayPresent;
        $absent[] = max($activeStudents - $dayPresent, 0);
    }

    return [
        'labels' => $labels,
        'present' => $present,
        'absent' => $absent,
    ];
}

function dashboard_month_chart(int $activeStudents): array
{
    $statement = db()->query(
        "SELECT attendance_date, COUNT(*) AS present_count
         FROM attendance_logs
         WHERE attendance_status = 'Present'
           AND attendance_date >= DATE_SUB(CURDATE(), INTERVAL 29 DAY)
         GROUP BY attendance_date"
    );

    $presentMap = [];
    foreach ($statement->fetchAll() as $row) {
        $presentMap[$row['attendance_date']] = (int) $row['present_count'];
    }

    $labels = [];
    $present = [];
    $absent = [];
    for ($offset = 29; $offset >= 0; $offset--) {
        $date = date('Y-m-d', strtotime('-' . $offset . ' day'));
        $dayPresent = $presentMap[$date] ?? 0;
        $labels[] = date('j', strtotime($date));
        $present[] = $dayPresent;
        $absent[] = max($activeStudents - $dayPresent, 0);
    }

    return [
        'labels' => $labels,
        'present' => $present,
        'absent' => $absent,
    ];
}

function dashboard_year_chart(int $activeStudents): array
{
    $statement = db()->query(
        "SELECT DATE_FORMAT(attendance_date, '%Y-%m') AS month_key, COUNT(*) AS present_count
         FROM attendance_logs
         WHERE attendance_status = 'Present'
           AND YEAR(attendance_date) = YEAR(CURDATE())
         GROUP BY DATE_FORMAT(attendance_date, '%Y-%m')"
    );

    $presentMap = [];
    foreach ($statement->fetchAll() as $row) {
        $presentMap[$row['month_key']] = (int) $row['present_count'];
    }

    $labels = [];
    $present = [];
    $absent = [];
    $currentYear = (int) date('Y');

    for ($month = 1; $month <= 12; $month++) {
        $monthKey = sprintf('%04d-%02d', $currentYear, $month);
        $monthStart = new DateTimeImmutable(sprintf('%04d-%02d-01', $currentYear, $month));
        $monthEnd = $monthStart->modify('last day of this month');
        if ($monthEnd > new DateTimeImmutable('today')) {
            $monthEnd = new DateTimeImmutable('today');
        }

        $workingDays = 0;
        $cursor = $monthStart;
        while ($cursor <= $monthEnd) {
            if ((int) $cursor->format('N') <= 5) {
                $workingDays++;
            }
            $cursor = $cursor->modify('+1 day');
        }

        $monthPresent = $presentMap[$monthKey] ?? 0;
        $labels[] = $monthStart->format('M');
        $present[] = $monthPresent;
        $absent[] = max(($activeStudents * $workingDays) - $monthPresent, 0);
    }

    return [
        'labels' => $labels,
        'present' => $present,
        'absent' => $absent,
    ];
}

function dashboard_peak_hours(): array
{
    $statement = db()->query(
        "SELECT HOUR(attendance_time) AS hour_number, COUNT(*) AS hits
         FROM attendance_logs
         WHERE attendance_date = CURDATE()
         GROUP BY HOUR(attendance_time)"
    );

    $map = [];
    foreach ($statement->fetchAll() as $row) {
        $map[(int) $row['hour_number']] = (int) $row['hits'];
    }

    $labels = [];
    $data = [];
    for ($hour = 8; $hour <= 17; $hour++) {
        $labels[] = date('gA', strtotime(sprintf('%02d:00:00', $hour)));
        $data[] = $map[$hour] ?? 0;
    }

    return [
        'labels' => $labels,
        'data' => $data,
    ];
}

try {
    $activeStudents = (int) db()->query("SELECT COUNT(*) FROM students WHERE status = 'Active'")->fetchColumn();
    $todayPresent = (int) db()->query(
        "SELECT COUNT(DISTINCT student_id)
         FROM attendance_logs
         WHERE attendance_status = 'Present'
           AND attendance_date = CURDATE()"
    )->fetchColumn();
    $todayAlerts = (int) db()->query(
        "SELECT COUNT(*)
         FROM alerts
         WHERE DATE(created_at) = CURDATE()"
    )->fetchColumn();
    $todayAbsent = max($activeStudents - $todayPresent, 0);
    $attendanceRate = $activeStudents > 0 ? round(($todayPresent / $activeStudents) * 100, 1) : 0;

    $recentActivityStatement = db()->query(
        "SELECT attendance_code, student_code, student_name, attendance_status, attendance_time
         FROM attendance_logs
         ORDER BY attendance_time DESC
         LIMIT 8"
    );
    $recentActivity = array_map(static function (array $row): array {
        return [
            'id' => $row['attendance_code'],
            'name' => $row['student_name'],
            'action' => strtolower($row['attendance_status']) === 'present' ? 'present' : 'alert',
            'time' => $row['attendance_time'],
            'studentId' => $row['student_code'] ?: 'UNKNOWN',
        ];
    }, $recentActivityStatement->fetchAll());

    $recentAlertsStatement = db()->query(
        "SELECT alert_code, reason, resolved, created_at
         FROM alerts
         ORDER BY created_at DESC
         LIMIT 5"
    );
    $recentAlerts = array_map(static function (array $row): array {
        return [
            'id' => $row['alert_code'],
            'time' => $row['created_at'],
            'reason' => $row['reason'],
            'resolved' => (bool) $row['resolved'],
        ];
    }, $recentAlertsStatement->fetchAll());

    $imagesStatement = db()->query(
        "SELECT id, reason, created_at, image_path
         FROM alerts
         WHERE image_path IS NOT NULL AND image_path <> ''
         ORDER BY created_at DESC
         LIMIT 8"
    );
    $unwantedImages = array_map(static function (array $row): array {
        return [
            'id' => (int) $row['id'],
            'url' => $row['image_path'],
            'reason' => $row['reason'],
            'time' => $row['created_at'],
        ];
    }, $imagesStatement->fetchAll());

    $weekChart = dashboard_week_chart($activeStudents);
    $peakHours = dashboard_peak_hours();

    json_response([
        'success' => true,
        'stats' => [
            'todayPresent' => $todayPresent,
            'todayAbsent' => $todayAbsent,
            'attendanceRate' => number_format($attendanceRate, 1) . '%',
            'todayAlerts' => $todayAlerts,
            'activeStudents' => $activeStudents,
        ],
        'charts' => [
            'attendance' => [
                'week' => $weekChart,
                'month' => dashboard_month_chart($activeStudents),
                'year' => dashboard_year_chart($activeStudents),
            ],
            'peakHours' => $peakHours,
            'distribution' => [
                'labels' => ['Present', 'Absent', 'Alerts'],
                'data' => [$todayPresent, $todayAbsent, $todayAlerts],
            ],
        ],
        'recentActivity' => $recentActivity,
        'recentAlerts' => $recentAlerts,
        'unwantedImages' => $unwantedImages,
    ]);
} catch (Throwable $exception) {
    fail_response('Unable to load dashboard data.', 500, [
        'details' => $exception->getMessage(),
    ]);
}
