<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

function system_attendance_days(): int
{
    $statement = db()->query(
        "SELECT COUNT(DISTINCT attendance_date)
         FROM attendance_logs
         WHERE attendance_status = 'Present'"
    );

    return (int) $statement->fetchColumn();
}

function fetch_students(): array
{
    $statement = db()->query(
        "SELECT s.*,
                COALESCE(checkins_summary.checkins, 0) AS checkins,
                COALESCE(checkins_summary.attendance_days, 0) AS attendance_days,
                checkins_summary.last_seen_at
         FROM students s
         LEFT JOIN (
             SELECT student_id,
                    COUNT(*) AS checkins,
                    COUNT(DISTINCT attendance_date) AS attendance_days,
                    MAX(attendance_time) AS last_seen_at
             FROM attendance_logs
             WHERE attendance_status = 'Present'
             GROUP BY student_id
         ) AS checkins_summary ON checkins_summary.student_id = s.id
         ORDER BY s.full_name ASC"
    );

    $days = system_attendance_days();
    $students = [];

    foreach ($statement->fetchAll() as $row) {
        $students[] = normalize_student($row, $days);
    }

    return $students;
}

try {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        json_response([
            'success' => true,
            'students' => fetch_students(),
        ]);
    }

    if ($method === 'DELETE') {
        $id = (int) (query_value('id', 0));
        if ($id <= 0) {
            fail_response('Student id is required.', 422);
        }

        $statement = db()->prepare('DELETE FROM students WHERE id = :id');
        $statement->execute(['id' => $id]);

        json_response([
            'success' => true,
            'message' => 'Student deleted successfully.',
            'students' => fetch_students(),
        ]);
    }

    $payload = request_data();
    $studentId = (int) ($payload['id'] ?? 0);
    $studentCode = trim((string) ($payload['studentCode'] ?? ''));
    $fullName = trim((string) ($payload['fullName'] ?? ''));

    if ($studentCode === '' || $fullName === '') {
        fail_response('Student code and full name are required.', 422);
    }

    $faceDescriptor = $payload['faceDescriptor'] ?? null;
    $encodedDescriptor = null;

    if (is_array($faceDescriptor)) {
        $encodedDescriptor = json_encode($faceDescriptor, JSON_UNESCAPED_SLASHES);
    } elseif (is_string($faceDescriptor) && trim($faceDescriptor) !== '') {
        $encodedDescriptor = $faceDescriptor;
    }

    $existingFacePath = trim((string) ($payload['existingFaceImageUrl'] ?? ''));
    $faceImagePath = save_base64_image($payload['faceImageBase64'] ?? null, 'students', 'student');
    if ($faceImagePath === null && $existingFacePath !== '') {
        $faceImagePath = $existingFacePath;
    }

    $existingDescriptor = trim((string) ($payload['existingFaceDescriptor'] ?? ''));
    if ($encodedDescriptor === null && $existingDescriptor !== '') {
        $encodedDescriptor = $existingDescriptor;
    }

    if ($studentId > 0) {
        $statement = db()->prepare(
            "UPDATE students
             SET student_code = :student_code,
                 full_name = :full_name,
                 class_name = :class_name,
                 roll_number = :roll_number,
                 email = :email,
                 phone = :phone,
                 parent_contact = :parent_contact,
                 status = :status,
                 face_descriptor = :face_descriptor,
                 face_image_path = :face_image_path
             WHERE id = :id"
        );
        $statement->execute([
            'id' => $studentId,
            'student_code' => $studentCode,
            'full_name' => $fullName,
            'class_name' => trim((string) ($payload['className'] ?? '')),
            'roll_number' => trim((string) ($payload['rollNumber'] ?? '')),
            'email' => trim((string) ($payload['email'] ?? '')),
            'phone' => trim((string) ($payload['phone'] ?? '')),
            'parent_contact' => trim((string) ($payload['parentContact'] ?? '')),
            'status' => trim((string) ($payload['status'] ?? 'Active')) ?: 'Active',
            'face_descriptor' => $encodedDescriptor,
            'face_image_path' => $faceImagePath,
        ]);
    } else {
        $statement = db()->prepare(
            "INSERT INTO students (
                student_code, full_name, class_name, roll_number, email, phone,
                parent_contact, status, face_descriptor, face_image_path
             ) VALUES (
                :student_code, :full_name, :class_name, :roll_number, :email, :phone,
                :parent_contact, :status, :face_descriptor, :face_image_path
             )"
        );
        $statement->execute([
            'student_code' => $studentCode,
            'full_name' => $fullName,
            'class_name' => trim((string) ($payload['className'] ?? '')),
            'roll_number' => trim((string) ($payload['rollNumber'] ?? '')),
            'email' => trim((string) ($payload['email'] ?? '')),
            'phone' => trim((string) ($payload['phone'] ?? '')),
            'parent_contact' => trim((string) ($payload['parentContact'] ?? '')),
            'status' => trim((string) ($payload['status'] ?? 'Active')) ?: 'Active',
            'face_descriptor' => $encodedDescriptor,
            'face_image_path' => $faceImagePath,
        ]);
    }

    json_response([
        'success' => true,
        'message' => 'Student saved successfully.',
        'students' => fetch_students(),
    ]);
} catch (Throwable $exception) {
    fail_response('Unable to process student request.', 500, [
        'details' => $exception->getMessage(),
    ]);
}
