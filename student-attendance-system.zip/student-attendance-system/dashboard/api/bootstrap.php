<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$appConfig = require __DIR__ . '/config.php';
date_default_timezone_set($appConfig['app']['timezone'] ?? 'Asia/Kolkata');

const PUBLIC_UPLOAD_ROOT = 'api/uploads';

function db(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    global $appConfig;

    $db = $appConfig['db'];
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        $db['host'],
        (int) $db['port'],
        $db['name']
    );

    $pdo = new PDO($dsn, $db['user'], $db['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    return $pdo;
}

function json_response(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function fail_response(string $message, int $status = 400, array $extra = []): void
{
    json_response(array_merge([
        'success' => false,
        'message' => $message,
    ], $extra), $status);
}

function request_data(): array
{
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (stripos($contentType, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        if ($raw === false || trim($raw) === '') {
            return [];
        }

        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    return $_POST;
}

function query_value(string $key, mixed $default = null): mixed
{
    return $_GET[$key] ?? $default;
}

function ensure_directory(string $path): void
{
    if (!is_dir($path)) {
        mkdir($path, 0777, true);
    }
}

function uploads_root(): string
{
    $path = __DIR__ . DIRECTORY_SEPARATOR . 'uploads';
    ensure_directory($path);

    return $path;
}

function save_base64_image(?string $base64Image, string $folder, string $prefix = 'capture'): ?string
{
    if ($base64Image === null || trim($base64Image) === '') {
        return null;
    }

    $extension = 'jpg';
    $payload = $base64Image;

    if (preg_match('/^data:image\/(\w+);base64,/', $base64Image, $matches) === 1) {
        $extension = strtolower($matches[1]);
        $payload = substr($base64Image, strpos($base64Image, ',') + 1);
    }

    $extension = in_array($extension, ['jpg', 'jpeg', 'png', 'webp'], true) ? $extension : 'jpg';
    $binary = base64_decode(str_replace(' ', '+', $payload), true);

    if ($binary === false) {
        return null;
    }

    $folderPath = uploads_root() . DIRECTORY_SEPARATOR . $folder;
    ensure_directory($folderPath);

    $filename = sprintf('%s_%s_%s.%s', $prefix, date('Ymd_His'), bin2hex(random_bytes(3)), $extension);
    $absolutePath = $folderPath . DIRECTORY_SEPARATOR . $filename;

    file_put_contents($absolutePath, $binary);

    return PUBLIC_UPLOAD_ROOT . '/' . $folder . '/' . $filename;
}

function app_defaults(): array
{
    global $appConfig;

    return [
        'institution_name' => 'Student Attendance System',
        'device_id' => $appConfig['app']['default_device_id'] ?? 'DASHBOARD-CAM-001',
        'wifi_ssid' => '',
        'wifi_password' => '',
        'telegram_bot_token' => '',
        'telegram_chat_id' => '',
        'ai_api_key' => '',
        'recognition_threshold' => '0.48',
        'unknown_alert_cooldown_seconds' => '30',
        'face_model_url' => 'https://justadudewhohacks.github.io/face-api.js/models',
        'server_recognition_model' => 'gpt-4.1-mini',
        'server_recognition_max_candidates' => '8',
        'esp32_api_token' => '',
        'notify_telegram' => '1',
        'notify_alerts' => '1',
        'daily_report_enabled' => '0',
    ];
}

function ensure_settings_table_exists(): void
{
    db()->exec(
        'CREATE TABLE IF NOT EXISTS settings (
            setting_key VARCHAR(100) NOT NULL,
            setting_value LONGTEXT NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )'
    );
}

function load_settings(): array
{
    ensure_settings_table_exists();

    $settings = app_defaults();

    $statement = db()->query('SELECT setting_key, setting_value FROM settings');
    foreach ($statement->fetchAll() as $row) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    return $settings;
}

function save_settings(array $pairs): void
{
    if ($pairs === []) {
        return;
    }

    ensure_settings_table_exists();

    $updateStatement = db()->prepare(
        'UPDATE settings
         SET setting_value = :setting_value
         WHERE setting_key = :setting_key'
    );
    $insertStatement = db()->prepare(
        'INSERT INTO settings (setting_key, setting_value)
         VALUES (:setting_key, :setting_value)'
    );

    foreach ($pairs as $key => $value) {
        $params = [
            'setting_key' => (string) $key,
            'setting_value' => is_scalar($value) ? (string) $value : json_encode($value, JSON_UNESCAPED_SLASHES),
        ];

        $updateStatement->execute($params);
        if ($updateStatement->rowCount() === 0) {
            $insertStatement->execute($params);
        }
    }
}

function as_bool(mixed $value): bool
{
    if (is_bool($value)) {
        return $value;
    }

    return in_array((string) $value, ['1', 'true', 'yes', 'on'], true);
}

function as_float(mixed $value, float $default = 0.0): float
{
    return is_numeric($value) ? (float) $value : $default;
}

function attendance_day_exists(int $studentId, string $date): bool
{
    $statement = db()->prepare(
        'SELECT id
         FROM attendance_logs
         WHERE student_id = :student_id
           AND attendance_status = :status
           AND attendance_date = :attendance_date
         LIMIT 1'
    );
    $statement->execute([
        'student_id' => $studentId,
        'status' => 'Present',
        'attendance_date' => $date,
    ]);

    return (bool) $statement->fetchColumn();
}

function next_code(string $prefix): string
{
    return $prefix . strtoupper(substr(bin2hex(random_bytes(5)), 0, 8));
}

function public_path_to_absolute(?string $publicPath): ?string
{
    if ($publicPath === null || trim($publicPath) === '') {
        return null;
    }

    $relative = str_replace(['\\', PUBLIC_UPLOAD_ROOT . '/'], ['/', ''], $publicPath);
    return uploads_root() . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
}

function telegram_enabled(array $settings): bool
{
    return as_bool($settings['notify_telegram'] ?? '0')
        && trim((string) ($settings['telegram_bot_token'] ?? '')) !== ''
        && trim((string) ($settings['telegram_chat_id'] ?? '')) !== '';
}

function send_telegram_photo(?string $publicPath, string $caption, array $settings): bool
{
    if (!telegram_enabled($settings)) {
        return false;
    }

    if (!function_exists('curl_init') || !class_exists('CURLFile')) {
        return false;
    }

    $absolutePath = public_path_to_absolute($publicPath);
    if ($absolutePath === null || !file_exists($absolutePath)) {
        return false;
    }

    $url = 'https://api.telegram.org/bot' . (string) $settings['telegram_bot_token'] . '/sendPhoto';

    $postFields = [
        'chat_id' => (string) $settings['telegram_chat_id'],
        'caption' => $caption,
        'photo' => new CURLFile($absolutePath),
    ];

    $curl = curl_init($url);
    curl_setopt_array($curl, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postFields,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
    ]);

    curl_exec($curl);
    $httpCode = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    return $httpCode === 200;
}

function normalize_student(array $student, int $systemAttendanceDays): array
{
    $descriptor = $student['face_descriptor'];
    $attendanceDays = (int) ($student['attendance_days'] ?? 0);

    return [
        'id' => (int) $student['id'],
        'studentCode' => $student['student_code'],
        'fullName' => $student['full_name'],
        'className' => $student['class_name'],
        'rollNumber' => $student['roll_number'],
        'email' => $student['email'],
        'phone' => $student['phone'],
        'parentContact' => $student['parent_contact'],
        'status' => $student['status'],
        'faceDescriptor' => $descriptor ? json_decode($descriptor, true) : null,
        'faceEnrolled' => $descriptor !== null && trim((string) $descriptor) !== '',
        'faceImageUrl' => $student['face_image_path'],
        'attendancePercentage' => $systemAttendanceDays > 0 ? round(($attendanceDays / $systemAttendanceDays) * 100, 1) : 0,
        'checkins' => (int) ($student['checkins'] ?? 0),
        'lastSeenAt' => $student['last_seen_at'],
        'createdAt' => $student['created_at'],
        'updatedAt' => $student['updated_at'],
    ];
}

function save_uploaded_image(array $file, string $folder, string $prefix = 'upload'): ?string
{
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return null;
    }

    $originalName = (string) ($file['name'] ?? '');
    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $extension = in_array($extension, ['jpg', 'jpeg', 'png', 'webp'], true) ? $extension : 'jpg';

    $folderPath = uploads_root() . DIRECTORY_SEPARATOR . $folder;
    ensure_directory($folderPath);

    $filename = sprintf('%s_%s_%s.%s', $prefix, date('Ymd_His'), bin2hex(random_bytes(3)), $extension);
    $absolutePath = $folderPath . DIRECTORY_SEPARATOR . $filename;

    if (!move_uploaded_file($file['tmp_name'], $absolutePath)) {
        return null;
    }

    return PUBLIC_UPLOAD_ROOT . '/' . $folder . '/' . $filename;
}

function detect_mime_type(string $absolutePath): string
{
    if (function_exists('mime_content_type')) {
        $mime = mime_content_type($absolutePath);
        if (is_string($mime) && $mime !== '') {
            return $mime;
        }
    }

    $extension = strtolower(pathinfo($absolutePath, PATHINFO_EXTENSION));
    return match ($extension) {
        'png' => 'image/png',
        'webp' => 'image/webp',
        default => 'image/jpeg',
    };
}

function public_path_to_data_url(?string $publicPath): ?string
{
    $absolutePath = public_path_to_absolute($publicPath);
    if ($absolutePath === null || !file_exists($absolutePath)) {
        return null;
    }

    $binary = file_get_contents($absolutePath);
    if ($binary === false) {
        return null;
    }

    return 'data:' . detect_mime_type($absolutePath) . ';base64,' . base64_encode($binary);
}

function fetch_recognition_candidates(int $limit = 8): array
{
    $statement = db()->prepare(
        "SELECT id, student_code, full_name, face_image_path
         FROM students
         WHERE status = 'Active'
           AND face_image_path IS NOT NULL
           AND face_image_path <> ''
         ORDER BY full_name ASC
         LIMIT :candidate_limit"
    );
    $statement->bindValue('candidate_limit', max(1, $limit), PDO::PARAM_INT);
    $statement->execute();

    return $statement->fetchAll();
}

function extract_json_object(string $text): ?array
{
    $decoded = json_decode($text, true);
    if (is_array($decoded)) {
        return $decoded;
    }

    if (preg_match('/\{.*\}/s', $text, $matches) !== 1) {
        return null;
    }

    $decoded = json_decode($matches[0], true);
    return is_array($decoded) ? $decoded : null;
}

function openai_responses_request(array $payload, string $apiKey): array
{
    if (!function_exists('curl_init')) {
        throw new RuntimeException('cURL is required for OpenAI server-side recognition.');
    }

    $curl = curl_init('https://api.openai.com/v1/responses');
    curl_setopt_array($curl, [
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
        ],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 60,
    ]);

    $rawResponse = curl_exec($curl);
    $httpCode = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $curlError = curl_error($curl);
    curl_close($curl);

    if ($rawResponse === false || $httpCode >= 400) {
        throw new RuntimeException('OpenAI recognition request failed. ' . trim($curlError . ' HTTP ' . $httpCode));
    }

    $decoded = json_decode($rawResponse, true);
    if (!is_array($decoded)) {
        throw new RuntimeException('OpenAI recognition response was not valid JSON.');
    }

    return $decoded;
}

function recognize_student_from_image(string $capturedImagePublicPath, array $settings): array
{
    $apiKey = trim((string) ($settings['ai_api_key'] ?? ''));
    if ($apiKey === '') {
        return [
            'matched' => false,
            'student_code' => null,
            'student_name' => null,
            'confidence' => 0,
            'reason' => 'AI API key is not configured for server-side recognition.',
        ];
    }

    $maxCandidates = max((int) ($settings['server_recognition_max_candidates'] ?? 8), 1);
    $candidates = fetch_recognition_candidates($maxCandidates);
    if ($candidates === []) {
        return [
            'matched' => false,
            'student_code' => null,
            'student_name' => null,
            'confidence' => 0,
            'reason' => 'No enrolled student face photos are available for matching.',
        ];
    }

    $capturedDataUrl = public_path_to_data_url($capturedImagePublicPath);
    if ($capturedDataUrl === null) {
        throw new RuntimeException('Unable to read uploaded ESP32 image for recognition.');
    }

    $content = [
        [
            'type' => 'input_text',
            'text' => 'Match the captured classroom face against the enrolled student photos. '
                . 'Focus only on face identity. Return JSON only with keys '
                . 'matched (boolean), student_code (string or null), student_name (string or null), '
                . 'confidence (number between 0 and 1), reason (string). '
                . 'Set matched=false when the face is unclear, multiple people appear, or no candidate is a confident match.'
        ],
        [
            'type' => 'input_text',
            'text' => 'Captured attendance image from ESP32-CAM:'
        ],
        [
            'type' => 'input_image',
            'image_url' => $capturedDataUrl,
            'detail' => 'low',
        ],
    ];

    $candidateCount = 0;
    foreach ($candidates as $index => $candidate) {
        $candidateImage = public_path_to_data_url($candidate['face_image_path']);
        if ($candidateImage === null) {
            continue;
        }

        $candidateCount++;

        $content[] = [
            'type' => 'input_text',
            'text' => sprintf(
                'Candidate %d: student_code=%s, student_name=%s',
                $index + 1,
                $candidate['student_code'],
                $candidate['full_name']
            ),
        ];
        $content[] = [
            'type' => 'input_image',
            'image_url' => $candidateImage,
            'detail' => 'low',
        ];
    }

    if ($candidateCount === 0) {
        return [
            'matched' => false,
            'student_code' => null,
            'student_name' => null,
            'confidence' => 0,
            'reason' => 'No readable enrolled student face photos were found on the server.',
        ];
    }

    $response = openai_responses_request([
        'model' => trim((string) ($settings['server_recognition_model'] ?? 'gpt-4.1-mini')) ?: 'gpt-4.1-mini',
        'input' => [[
            'role' => 'user',
            'content' => $content,
        ]],
    ], $apiKey);

    $outputText = trim((string) ($response['output_text'] ?? ''));
    $parsed = extract_json_object($outputText);

    if ($parsed === null) {
        return [
            'matched' => false,
            'student_code' => null,
            'student_name' => null,
            'confidence' => 0,
            'reason' => 'Recognition response could not be parsed.',
        ];
    }

    return [
        'matched' => (bool) ($parsed['matched'] ?? false),
        'student_code' => $parsed['student_code'] ?? null,
        'student_name' => $parsed['student_name'] ?? null,
        'confidence' => as_float($parsed['confidence'] ?? 0),
        'reason' => trim((string) ($parsed['reason'] ?? '')),
    ];
}
