# Student Attendance System with ESP32-CAM

## Current Scope

- [x] PIR motion detection
- [x] ESP32-CAM image capture
- [x] Telegram photo notification
- [x] OpenAI suspicious-image check
- [x] Serial attendance logging
- [x] Local dashboard UI
- [x] Remove Google Sheets dependency

## Next Optional Improvements

- [ ] Add face recognition for real student IDs
- [ ] Add a local backend for live dashboard data
- [ ] Save attendance to SQLite or CSV
- [ ] Add export from dashboard
- [ ] Add multi-device support
