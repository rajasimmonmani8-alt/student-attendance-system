#ifndef ESP32_CAM_CONFIG_H
#define ESP32_CAM_CONFIG_H

// ============================================
// WIFI CONFIGURATION
// ============================================
const char* ssid = "simmon";
const char* password = "raja1234";

// ============================================
// ESP32-CAM PIN DEFINITIONS
// ============================================
#define PIR_PIN 13          // PIR motion sensor pin (GPIO 13)
#define BUZZER_PIN 12       // Avoid external pull-up on GPIO 12; disconnect during upload if needed
#define LED_FLASH 4         // Built-in LED flash (GPIO 4)
#define LED_BUILTIN 33      // Built-in status LED (GPIO 33)

// ============================================
// CAMERA MODEL - AI THINKER
// ============================================
#define CAMERA_MODEL_AI_THINKER
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

// ============================================
// TELEGRAM BOT CONFIGURATION
// ============================================
const char* botToken = "8746527479:AAEom11NFjjxA-3WQ4iH7bN40NHoGIbT8h8";
const char* chatId = "5803560521";

// ============================================
// TIMING CONFIGURATIONS (in milliseconds)
// ============================================
#define MOTION_COOLDOWN 5000        // Cooldown between motion detections
#define CAPTURE_DELAY 1000          // Delay before capturing image
#define BUZZER_DURATION 200         // Buzzer beep duration
#define TELEGRAM_TIMEOUT 10000      // Telegram API timeout

// ============================================
// IMAGE SETTINGS
// ============================================
#define IMAGE_QUALITY 12            // JPEG quality (0-63, lower = better)
#define IMAGE_WIDTH 800             // Reserved for future use
#define IMAGE_HEIGHT 600            // Reserved for future use

// ============================================
// ATTENDANCE SETTINGS
// ============================================
const char* institutionName = "MREC";
const char* deviceId = "CAM-001";
const char* attendanceApiUrl = "http://10.84.59.117/student-attendance-system/dashboard/api/esp32_attendance.php";
const char* attendanceApiToken = "ESP32_SECURE_9xK#21_attendance";

#endif
