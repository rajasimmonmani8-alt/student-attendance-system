#ifndef STUDENT_ATTENDANCE_LOCAL_CONFIG_H
#define STUDENT_ATTENDANCE_LOCAL_CONFIG_H

#include "../config.h"

#endif
