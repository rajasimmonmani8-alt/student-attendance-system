/*
 * Student Attendance System with ESP32-CAM
 * Features: PIR Motion Detection, Image Capture, Telegram Alerts,
 *           Serial Attendance Logging, Server-side Attendance Recognition
 * 
 * Hardware: ESP32-CAM, PIR Sensor, Buzzer
 * Author: SuperNinja AI
 * Version: 1.0.0
 */

#include "config.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ctype.h>
#include <time.h>
#include "esp_camera.h"

// ============================================
// GLOBAL VARIABLES
// ============================================
bool motionDetected = false;
unsigned long lastMotionTime = 0;
int attendanceCount = 0;
String currentSessionId = "";

struct ServerRecognitionResult {
    bool requestOk;
    bool recognized;
    bool duplicate;
    bool suppressed;
    float confidence;
    String studentCode;
    String studentName;
    String message;
};

// ============================================
// CAMERA CONFIGURATION
// ============================================
void initCamera() {
    camera_config_t config;
    memset(&config, 0, sizeof(config));
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = Y2_GPIO_NUM;
    config.pin_d1 = Y3_GPIO_NUM;
    config.pin_d2 = Y4_GPIO_NUM;
    config.pin_d3 = Y5_GPIO_NUM;
    config.pin_d4 = Y6_GPIO_NUM;
    config.pin_d5 = Y7_GPIO_NUM;
    config.pin_d6 = Y8_GPIO_NUM;
    config.pin_d7 = Y9_GPIO_NUM;
    config.pin_xclk = XCLK_GPIO_NUM;
    config.pin_pclk = PCLK_GPIO_NUM;
    config.pin_vsync = VSYNC_GPIO_NUM;
    config.pin_href = HREF_GPIO_NUM;
    config.pin_sccb_sda = SIOD_GPIO_NUM;
    config.pin_sccb_scl = SIOC_GPIO_NUM;
    config.pin_pwdn = PWDN_GPIO_NUM;
    config.pin_reset = RESET_GPIO_NUM;
    config.xclk_freq_hz = 20000000;
    config.frame_size = psramFound() ? FRAMESIZE_SVGA : FRAMESIZE_VGA;
    config.pixel_format = PIXFORMAT_JPEG;
    config.grab_mode = CAMERA_GRAB_LATEST;
    config.fb_location = psramFound() ? CAMERA_FB_IN_PSRAM : CAMERA_FB_IN_DRAM;
    config.jpeg_quality = IMAGE_QUALITY;
    config.fb_count = psramFound() ? 2 : 1;

    // Initialize camera
    esp_err_t err = esp_camera_init(&config);
    if (err != ESP_OK) {
        Serial.printf("Camera init failed with error 0x%x", err);
        return;
    }
    
    Serial.println("Camera initialized successfully!");
}

// ============================================
// WIFI CONNECTION
// ============================================
void connectWiFi() {
    WiFi.begin(ssid, password);
    Serial.print("Connecting to WiFi");
    
    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 30) {
        delay(500);
        Serial.print(".");
        attempts++;
    }
    
    if (WiFi.status() == WL_CONNECTED) {
        Serial.println("\nWiFi connected!");
        Serial.print("IP Address: ");
        Serial.println(WiFi.localIP());
    } else {
        Serial.println("\nWiFi connection failed!");
    }
}

// ============================================
// BUZZER FUNCTIONS
// ============================================
void beepBuzzer(int times = 1, int duration = BUZZER_DURATION) {
    for (int i = 0; i < times; i++) {
        digitalWrite(BUZZER_PIN, HIGH);
        delay(duration);
        digitalWrite(BUZZER_PIN, LOW);
        if (times > 1 && i < times - 1) {
            delay(100);
        }
    }
}

void beepSuccess() {
    beepBuzzer(2, 100);  // Two short beeps for success
}

void beepAlert() {
    beepBuzzer(3, 300);  // Three longer beeps for alert
}

// ============================================
// FLASH LED CONTROL
// ============================================
void flashLED(bool state) {
    digitalWrite(LED_FLASH, state ? HIGH : LOW);
}

// ============================================
// IMAGE CAPTURE
// ============================================
camera_fb_t* captureImage() {
    flashLED(true);
    delay(CAPTURE_DELAY);
    
    camera_fb_t* fb = esp_camera_fb_get();
    
    flashLED(false);
    
    if (!fb) {
        Serial.println("Camera capture failed!");
        return NULL;
    }
    
    Serial.printf("Image captured! Size: %u bytes\n", static_cast<unsigned int>(fb->len));
    return fb;
}

// ============================================
// TELEGRAM NOTIFICATIONS
// ============================================
bool sendTelegramPhoto(camera_fb_t* fb, String caption) {
    if (!fb) return false;
    
    WiFiClientSecure client;
    client.setInsecure();
    
    String url = "https://api.telegram.org/bot" + String(botToken) + "/sendPhoto";
    
    HTTPClient http;
    http.begin(client, url);
    
    String boundary = "--------------------------" + String(random(0xFFFFFF), HEX);
    String contentType = "multipart/form-data; boundary=" + boundary;
    http.addHeader("Content-Type", contentType);
    
    String body = "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n";
    body += String(chatId) + "\r\n";
    
    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"photo\"; filename=\"attendance.jpg\"\r\n";
    body += "Content-Type: image/jpeg\r\n\r\n";
    
    String tail = "\r\n--" + boundary + "\r\n";
    tail += "Content-Disposition: form-data; name=\"caption\"\r\n\r\n";
    tail += caption + "\r\n";
    tail += "--" + boundary + "--\r\n";
    
    int bodyLength = body.length() + fb->len + tail.length();
    uint8_t* buffer = (uint8_t*)malloc(bodyLength);
    
    if (buffer) {
        memcpy(buffer, body.c_str(), body.length());
        memcpy(buffer + body.length(), fb->buf, fb->len);
        memcpy(buffer + body.length() + fb->len, tail.c_str(), tail.length());
        
        int httpCode = http.POST(buffer, bodyLength);
        free(buffer);
        
        if (httpCode == HTTP_CODE_OK) {
            Serial.println("Photo sent to Telegram successfully!");
            return true;
        } else {
            Serial.printf("Telegram Error: %d\n", httpCode);
        }
    }
    
    http.end();
    return false;
}

bool sendTelegramMessage(String message) {
    WiFiClientSecure client;
    client.setInsecure();
    
    String url = "https://api.telegram.org/bot" + String(botToken) + "/sendMessage";
    
    HTTPClient http;
    http.begin(client, url);
    http.addHeader("Content-Type", "application/x-www-form-urlencoded");
    
    String postData = "chat_id=" + String(chatId) + "&text=" + message + "&parse_mode=HTML";
    
    int httpCode = http.POST(postData);
    http.end();
    
    return httpCode == HTTP_CODE_OK;
}

// ============================================
// LIGHTWEIGHT JSON HELPERS
// ============================================
int findJsonValueStart(const String& json, const String& key) {
    String token = "\"" + key + "\"";
    int keyIndex = json.indexOf(token);
    if (keyIndex < 0) {
        return -1;
    }

    int colonIndex = json.indexOf(':', keyIndex + token.length());
    if (colonIndex < 0) {
        return -1;
    }

    int valueStart = colonIndex + 1;
    while (valueStart < json.length() && isspace(static_cast<unsigned char>(json[valueStart]))) {
        valueStart++;
    }

    return valueStart;
}

bool readJsonBool(const String& json, const String& key, bool defaultValue) {
    int valueStart = findJsonValueStart(json, key);
    if (valueStart < 0) {
        return defaultValue;
    }

    if (json.startsWith("true", valueStart)) {
        return true;
    }

    if (json.startsWith("false", valueStart)) {
        return false;
    }

    return defaultValue;
}

float readJsonFloat(const String& json, const String& key, float defaultValue) {
    int valueStart = findJsonValueStart(json, key);
    if (valueStart < 0) {
        return defaultValue;
    }

    int valueEnd = valueStart;
    while (valueEnd < json.length()) {
        char current = json[valueEnd];
        if ((current >= '0' && current <= '9') || current == '-' || current == '+' || current == '.') {
            valueEnd++;
            continue;
        }
        break;
    }

    if (valueEnd == valueStart) {
        return defaultValue;
    }

    return json.substring(valueStart, valueEnd).toFloat();
}

String readJsonString(const String& json, const String& key, const String& defaultValue) {
    int valueStart = findJsonValueStart(json, key);
    if (valueStart < 0 || valueStart >= json.length() || json[valueStart] != '"') {
        return defaultValue;
    }

    valueStart++;
    String value = "";

    for (int i = valueStart; i < json.length(); i++) {
        char current = json[i];
        if (current == '"' && json[i - 1] != '\\') {
            return value;
        }
        value += current;
    }

    return defaultValue;
}

// ============================================
// SERVER-SIDE ATTENDANCE API
// ============================================
ServerRecognitionResult postImageToAttendanceApi(camera_fb_t* fb) {
    ServerRecognitionResult result = {false, false, false, false, 0.0f, "", "", "Server request failed"};

    if (!fb) {
        result.message = "Camera buffer is empty";
        return result;
    }

    HTTPClient http;
    http.begin(String(attendanceApiUrl));

    String boundary = "--------------------------" + String(random(0xFFFFFF), HEX);
    http.addHeader("Content-Type", "multipart/form-data; boundary=" + boundary);

    String body = "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"device_id\"\r\n\r\n";
    body += String(deviceId) + "\r\n";

    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"api_token\"\r\n\r\n";
    body += String(attendanceApiToken) + "\r\n";

    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"photo\"; filename=\"esp32_attendance.jpg\"\r\n";
    body += "Content-Type: image/jpeg\r\n\r\n";

    String tail = "\r\n--" + boundary + "--\r\n";
    int bodyLength = body.length() + fb->len + tail.length();
    uint8_t* buffer = (uint8_t*)malloc(bodyLength);

    if (!buffer) {
        http.end();
        result.message = "Not enough memory for server upload";
        return result;
    }

    memcpy(buffer, body.c_str(), body.length());
    memcpy(buffer + body.length(), fb->buf, fb->len);
    memcpy(buffer + body.length() + fb->len, tail.c_str(), tail.length());

    int httpCode = http.POST(buffer, bodyLength);
    free(buffer);

    if (httpCode <= 0) {
        result.message = "Attendance API connection failed";
        http.end();
        return result;
    }

    String response = http.getString();
    http.end();

    if (response.length() == 0) {
        result.message = "Empty response from attendance API";
        return result;
    }

    result.requestOk = readJsonBool(response, "success", false);
    result.recognized = readJsonBool(response, "recognized", false);
    result.duplicate = readJsonBool(response, "duplicate", false);
    result.suppressed = readJsonBool(response, "suppressed", false);
    result.confidence = readJsonFloat(response, "confidence", 0.0f);
    result.studentCode = readJsonString(response, "studentCode", "");
    result.studentName = readJsonString(response, "studentName", "");
    result.message = readJsonString(response, "message", "No message from server");

    return result;
}

// ============================================
// ATTENDANCE LOGGING
// ============================================
void logAttendanceEvent(String studentId, String status, String timestamp, bool isUnwanted) {
    Serial.println("----- Attendance Event -----");
    Serial.println("Student ID: " + studentId);
    Serial.println("Status: " + status);
    Serial.println("Timestamp: " + timestamp);
    Serial.println("Device ID: " + String(deviceId));
    Serial.println("AI Flagged: " + String(isUnwanted ? "YES" : "NO"));
    Serial.println("----------------------------");
}

// ============================================
// GET CURRENT TIMESTAMP
// ============================================
String getTimestamp() {
    struct tm timeinfo;
    if (!getLocalTime(&timeinfo)) {
        return "1970-01-01 00:00:00";
    }
    
    char timeStringBuff[50];
    strftime(timeStringBuff, sizeof(timeStringBuff), "%Y-%m-%d %H:%M:%S", &timeinfo);
    return String(timeStringBuff);
}

// ============================================
// GENERATE SESSION ID
// ============================================
String generateSessionId() {
    return "ATT" + String(random(100000, 999999));
}

// ============================================
// MOTION DETECTION HANDLER
// ============================================
void handleMotion() {
    unsigned long currentTime = millis();
    
    // Check cooldown
    if (currentTime - lastMotionTime < MOTION_COOLDOWN) {
        return;
    }
    
    lastMotionTime = currentTime;
    motionDetected = true;
    
    Serial.println("\n=== MOTION DETECTED ===");
    
    // Generate session ID
    currentSessionId = generateSessionId();
    String timestamp = getTimestamp();
    
    // Capture image
    Serial.println("Capturing image...");
    camera_fb_t* fb = captureImage();
    
    if (fb) {
        // Beep to indicate capture
        beepBuzzer(1);

        Serial.println("Uploading image to PHP attendance API...");
        ServerRecognitionResult serverResult = postImageToAttendanceApi(fb);

        if (serverResult.requestOk && serverResult.recognized) {
            String attendanceStatus = serverResult.duplicate ? "DUPLICATE" : "PRESENT";

            if (!serverResult.duplicate) {
                attendanceCount++;
                beepSuccess();
            } else {
                beepBuzzer(1, 120);
            }

            Serial.println("Attendance API: " + serverResult.message);
            if (serverResult.studentName.length() > 0) {
                Serial.println("Matched Student: " + serverResult.studentName + " (" + serverResult.studentCode + ")");
            }

            logAttendanceEvent(serverResult.studentCode, attendanceStatus, timestamp, false);
        } else if (serverResult.requestOk) {
            beepAlert();
            Serial.println("Attendance API: " + serverResult.message);
            logAttendanceEvent("UNKNOWN", serverResult.suppressed ? "ALERT_SUPPRESSED" : "ALERT", timestamp, true);
        } else {
            beepAlert();
            Serial.println("Attendance API Error: " + serverResult.message);
            logAttendanceEvent("UPLOAD_FAILED", "ERROR", timestamp, true);
            sendTelegramMessage("ESP32-CAM could not reach the attendance server. Check XAMPP and the PHP API URL.");
        }
        
        // Release image buffer
        esp_camera_fb_return(fb);
    }
}

// ============================================
// PIR SENSOR INTERRUPT
// ============================================
void IRAM_ATTR pirInterrupt() {
    motionDetected = true;
}

// ============================================
// SETUP
// ============================================
void setup() {
    Serial.begin(115200);
    Serial.println("\n\n========================================");
    Serial.println("Student Attendance System v1.0");
    Serial.println("========================================\n");
    
    // Initialize pins
    pinMode(PIR_PIN, INPUT);
    pinMode(BUZZER_PIN, OUTPUT);
    pinMode(LED_FLASH, OUTPUT);
    pinMode(LED_BUILTIN, OUTPUT);
    
    digitalWrite(BUZZER_PIN, LOW);
    digitalWrite(LED_FLASH, LOW);
    digitalWrite(LED_BUILTIN, HIGH);  // LED off (active low)
    
    // Connect to WiFi
    connectWiFi();
    
    // Initialize camera
    initCamera();
    
    // Configure time
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    
    // Attach interrupt for PIR sensor
    attachInterrupt(digitalPinToInterrupt(PIR_PIN), pirInterrupt, RISING);
    
    // Startup beep
    beepBuzzer(3, 100);
    
    Serial.println("\nSystem Ready!");
    Serial.println("Waiting for motion detection...\n");
    
    // Send startup notification
    sendTelegramMessage("Student Attendance System Online\n"
                        "Device: " + String(deviceId) + "\n"
                        "Status: Ready\n"
                        "Time: " + getTimestamp());
}

// ============================================
// MAIN LOOP
// ============================================
void loop() {
    // Handle motion detection
    if (motionDetected) {
        handleMotion();
        motionDetected = false;
    }
    
    // Maintain WiFi connection
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("WiFi disconnected. Reconnecting...");
        connectWiFi();
    }
    
    // Blink status LED
    static unsigned long lastBlink = 0;
    if (millis() - lastBlink > 1000) {
        digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
        lastBlink = millis();
    }
    
    delay(100);
}
