# Student Attendance System with ESP32-CAM

This project now includes two parts:

- ESP32-CAM motion capture and Telegram alert firmware
- A XAMPP + MySQL dashboard with face-recognition automatic attendance

The dashboard is no longer demo-only. It now supports:

- Student face enrollment
- Automatic webcam-based face recognition
- ESP32-CAM image upload to PHP API
- Server-side student recognition from ESP32 captures
- Attendance saved in MySQL
- Unknown-person alert snapshots saved in MySQL
- Unknown-person image sending to Telegram
- Daily, weekly, and monthly reports from live database data

## What You Need

### Hardware
- ESP32-CAM AI Thinker
- PIR sensor HC-SR501
- Active buzzer
- FTDI USB-to-TTL programmer
- 5V 2A power supply
- Jumper wires
- Breadboard or PCB

### Software
- Arduino IDE
- ESP32 board package
- ArduinoJson library
- Base64 library
- Telegram account for bot setup
- OpenAI API key
- XAMPP (Apache + MySQL + PHP)
- Any modern browser for the dashboard

## Wiring

- PIR `VCC` -> ESP32-CAM `5V`
- PIR `GND` -> ESP32-CAM `GND`
- PIR `OUT` -> ESP32-CAM `GPIO 13`
- Buzzer `+` -> ESP32-CAM `GPIO 12`
- Buzzer `-` -> ESP32-CAM `GND`
- FTDI `TX` -> ESP32-CAM `U0R`
- FTDI `RX` -> ESP32-CAM `U0T`
- FTDI `5V` -> ESP32-CAM `5V`
- FTDI `GND` -> ESP32-CAM `GND`
- During upload only: connect `GPIO 0` to `GND`

More pin details: [documentation/pinout_reference.md](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/documentation/pinout_reference.md)

## Quick Start

1. Open [esp32-cam/config.h](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/esp32-cam/config.h) and fill in WiFi, Telegram, and OpenAI values.
2. Upload [esp32-cam/student_attendance.ino](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/esp32-cam/student_attendance.ino) to the ESP32-CAM.
3. Open Serial Monitor at `115200`.
4. Power the board normally and test motion in front of the PIR sensor.
5. Import [database/student_attendance_system.sql](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/database/student_attendance_system.sql) into phpMyAdmin.
6. Serve the project through XAMPP and open the dashboard in a browser.

Full local setup: [documentation/xampp_mysql_setup.md](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/documentation/xampp_mysql_setup.md)

## Project Files

- [esp32-cam/student_attendance.ino](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/esp32-cam/student_attendance.ino): firmware
- [esp32-cam/config.h](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/esp32-cam/config.h): credentials and pin setup
- [dashboard/index.html](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/dashboard/index.html): dashboard UI
- [dashboard/script.js](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/dashboard/script.js): dashboard logic
- [dashboard/api/bootstrap.php](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/dashboard/api/bootstrap.php): shared PHP backend helpers
- [dashboard/api/attendance.php](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/dashboard/api/attendance.php): attendance + unknown-person alert API
- [dashboard/api/students.php](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/dashboard/api/students.php): student enrollment API
- [database/student_attendance_system.sql](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/database/student_attendance_system.sql): MySQL schema
- [documentation/setup_guide.md](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/documentation/setup_guide.md): full step-by-step guide

## Important Note

The dashboard now needs Apache/PHP/MySQL to run correctly. Open it through XAMPP, not directly from the file system.
