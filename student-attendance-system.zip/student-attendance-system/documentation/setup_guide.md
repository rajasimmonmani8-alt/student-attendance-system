# Student Attendance System Setup Guide

This guide is for the Google-Sheets-free version of the project.

## 1. Hardware Required

| Item | Qty | Notes |
|---|---:|---|
| ESP32-CAM AI Thinker | 1 | Main board |
| PIR sensor HC-SR501 | 1 | Motion detection |
| Active buzzer | 1 | Audio indication |
| FTDI programmer | 1 | For uploading code |
| 5V 2A power supply | 1 | Stable power is important |
| Jumper wires | 8+ | Connections |
| Breadboard or PCB | 1 | Optional but helpful |

## 2. Hardware Connection Step by Step

### PIR Sensor
- `VCC` -> `5V`
- `GND` -> `GND`
- `OUT` -> `GPIO 13`

### Buzzer
- `+` -> `GPIO 12`
- `-` -> `GND`

### FTDI Programmer
- `TX` -> `U0R / GPIO 3`
- `RX` -> `U0T / GPIO 1`
- `5V` -> `5V`
- `GND` -> `GND`

### Upload Mode
- Connect `GPIO 0` to `GND`
- Press reset when Arduino IDE starts uploading
- After upload, remove `GPIO 0` from `GND`
- Press reset again for normal run mode

## 3. Arduino IDE Setup

1. Install Arduino IDE.
2. Open `File -> Preferences`.
3. Add this board URL:

```text
https://dl.espressif.com/dl/package_esp32_index.json
```

4. Open `Tools -> Board -> Boards Manager`.
5. Install `ESP32 by Espressif Systems`.

## 4. Libraries to Install

Install these from `Sketch -> Include Library -> Manage Libraries`:

- `ArduinoJson`
- `Base64`

These are already provided by the ESP32 board package:

- `WiFi`
- `WiFiClientSecure`
- `HTTPClient`

## 5. Firmware Configuration

Open [config.h](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/esp32-cam/config.h) and update:

```cpp
const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";

const char* botToken = "YOUR_TELEGRAM_BOT_TOKEN";
const char* chatId = "YOUR_TELEGRAM_CHAT_ID";

const char* aiApiKey = "YOUR_OPENAI_API_KEY";
const char* attendanceApiUrl = "http://YOUR_PC_IP/student-attendance-system/dashboard/api/esp32_attendance.php";
const char* attendanceApiToken = "YOUR_SHARED_ESP32_API_TOKEN";
```

Important:

- `attendanceApiUrl` must use your computer IP on the same WiFi network
- do not use `localhost`
- the token must match the dashboard `ESP32 API Token`

## 6. Telegram Bot Setup

1. Open Telegram.
2. Search `@BotFather`.
3. Send `/newbot`.
4. Create your bot name and username.
5. Copy the bot token.
6. Open a chat with your bot and send one message.
7. Open:

```text
https://api.telegram.org/botYOUR_BOT_TOKEN/getUpdates
```

8. Find your chat ID and place it in `config.h`.

## 7. OpenAI Setup

1. Create an API key in your OpenAI account.
2. Paste the key into `aiApiKey` in `config.h`.
3. Keep enough API balance available for image analysis.

## 8. Upload Firmware

1. Open [student_attendance.ino](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/esp32-cam/student_attendance.ino).
2. Select board: `AI Thinker ESP32-CAM`.
3. Select the correct COM port.
4. Set upload speed to `115200` or `921600` if stable.
5. Keep `GPIO 0` connected to `GND`.
6. Click `Upload`.
7. Press `RST` when upload begins if needed.
8. Remove `GPIO 0` from `GND`.
9. Press `RST` again.

## 9. First Power-On Test

1. Open Serial Monitor at `115200`.
2. Confirm WiFi connects.
3. Confirm camera initializes.
4. Confirm startup Telegram message arrives.
5. Move in front of the PIR sensor.
6. Confirm the board captures an image.
7. Confirm Telegram receives the image.
8. Confirm Serial Monitor shows an attendance event.

## 10. Dashboard Use

The dashboard in this project now uses XAMPP + MySQL and supports:

- student face enrollment
- browser camera face recognition
- ESP32-CAM image upload to PHP API
- MySQL attendance logs
- unknown-person Telegram alerts

Run it through XAMPP and open:

```text
http://localhost/student-attendance-system/dashboard/
```

Then:

1. import the MySQL file
2. save dashboard settings
3. add students with face photos
4. set the ESP32 API token
5. upload the firmware
6. test motion in front of the ESP32-CAM

## 11. Troubleshooting

### ESP32-CAM not booting
- Use a stable `5V 2A` supply
- Do not rely on weak USB power only

### Upload failing
- Check FTDI wiring
- Keep `GPIO 0` connected to `GND` during upload
- Press reset once upload starts

### Camera init failed
- Recheck the camera ribbon cable
- Confirm you selected `AI Thinker ESP32-CAM`

### No Telegram message
- Recheck bot token
- Recheck chat ID
- Make sure the bot already received one message from you

### AI analysis not working
- Recheck OpenAI key
- Confirm internet access on the WiFi network

### PIR not detecting
- Recheck `GPIO 13`
- Adjust PIR sensitivity knob
- Wait a few seconds after power-on because PIR modules stabilize slowly

## 12. Current Working Scope

Working now:
- motion detection
- image capture
- AI suspicious-image check
- Telegram alert/photo delivery
- serial attendance logging
- local dashboard UI

Not included now:
- direct on-device face recognition without the PHP/OpenAI server
