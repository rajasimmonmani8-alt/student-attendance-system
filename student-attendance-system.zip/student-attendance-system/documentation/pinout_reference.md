# ESP32-CAM Pinout Reference

## Project Pins

| GPIO | Use in this project | Notes |
|---|---|---|
| 4 | Flash LED | Built into ESP32-CAM |
| 12 | Buzzer | Boot-sensitive pin, keep wiring simple |
| 13 | PIR sensor output | Motion input |
| 33 | Status LED | Built into board on some variants |

## AI Thinker Camera Pins

These are reserved by the camera and should not be reused:

| GPIO | Camera signal |
|---|---|
| 0 | XCLK |
| 5 | Y2 |
| 18 | Y3 |
| 19 | Y4 |
| 21 | Y5 |
| 22 | PCLK |
| 23 | HREF |
| 25 | VSYNC |
| 26 | SIOD |
| 27 | SIOC |
| 32 | PWDN |
| 34 | Y8 |
| 35 | Y9 |
| 36 | Y6 |
| 39 | Y7 |

## Upload Wiring

| FTDI | ESP32-CAM |
|---|---|
| TX | U0R / GPIO 3 |
| RX | U0T / GPIO 1 |
| 5V | 5V |
| GND | GND |

## Important Boot Notes

- `GPIO 0` must be connected to `GND` only while uploading.
- Remove that connection after upload for normal boot.
- `GPIO 12` is a strapping pin, so avoid heavy external circuits on it.
- Use a proper `5V 2A` power supply for stable camera operation.
