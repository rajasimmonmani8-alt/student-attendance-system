# XAMPP + MySQL Setup

## 1. Copy the project into XAMPP

Move or copy this project into your XAMPP web root, for example:

`C:\xampp\htdocs\student-attendance-system`

Then open the dashboard from:

`http://localhost/student-attendance-system/dashboard/`

## 2. Create the database

1. Start `Apache` and `MySQL` from the XAMPP Control Panel.
2. Open `http://localhost/phpmyadmin/`.
3. Import [database/student_attendance_system.sql](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/database/student_attendance_system.sql).

Default database name:

`student_attendance_system`

## 3. Check the PHP database config

Open [dashboard/api/config.php](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/dashboard/api/config.php).

Default values are:

- Host: `127.0.0.1`
- Port: `3306`
- Database: `student_attendance_system`
- User: `root`
- Password: empty

If your XAMPP MySQL settings are different, update them there.

## 4. Open the dashboard

Open:

`http://localhost/student-attendance-system/dashboard/`

The dashboard must be opened through Apache/XAMPP, not by double-clicking `index.html`, because the frontend now uses PHP API endpoints.

## 5. Save your settings

In the dashboard `Settings` page, fill in:

- Institution name
- Dashboard device ID
- Telegram bot token
- Telegram chat ID
- Recognition threshold
- Unknown alert cooldown
- Server recognition model
- Server candidate limit
- ESP32 API token

Then click `Save Settings`.

## 6. Enroll students

1. Go to the `Students` page.
2. Click `Add Student`.
3. Enter the student details.
4. Upload a clear front-facing face photo.
5. Save the student.

The face descriptor is generated in the browser and saved into MySQL.

## 7. Start automatic recognition

1. Go to the `Recognition` page.
2. Allow camera access in the browser.
3. Click `Start Camera`.

What happens:

- Recognized students are marked present automatically.
- Duplicate attendance for the same day is blocked.
- Unknown people create alert records.
- Unknown-person snapshots are sent to Telegram when Telegram settings are enabled.

## 8. Connect ESP32-CAM to the PHP attendance API

Open [esp32-cam/config.h](/C:/Users/ELCOT/Desktop/projects/Student%20Attendance%20System/esp32-cam/config.h) and set:

- `attendanceApiUrl`
- `attendanceApiToken`

Important:

- Do not use `localhost` in `attendanceApiUrl`
- Use your computer's local LAN IP address instead

Example:

`http://192.168.1.100/student-attendance-system/dashboard/api/esp32_attendance.php`

The `attendanceApiToken` in the firmware must exactly match the `ESP32 API Token` saved in the dashboard settings.

## 9. Face model files

By default the dashboard loads face recognition model files from:

`https://justadudewhohacks.github.io/face-api.js/models`

If you want fully local/offline recognition:

1. Download the face-api.js model files.
2. Put them in a local folder inside the dashboard, for example `dashboard/models`.
3. In `Settings`, change `Face Model URL` to `models`.

## 10. Important notes

- The browser must have camera permission.
- The first model load can take a little time.
- Telegram photo sending depends on valid bot token and chat ID.
- The ESP32 firmware can now post captured images directly to `dashboard/api/esp32_attendance.php`.
- Server-side student matching uses the saved student face photos plus your OpenAI API key.
